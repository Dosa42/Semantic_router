"""
UAGL_BROTHERHOOD_TEAM · TRINITY PEER MANAGER
=====================

Centralized peer connection management:
- Peer discovery via tracker + DHT
- Periodic sync with connected peers (every 30s)
- Piece exchange coordination
- Connection health monitoring
- Multi-node topology support (Master/Relay/Edge/Peer)

@author VEKIL-KAAN / SATEN
@version 3.0-UAGL-KARARGAH
"""

import asyncio
import logging
import time
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set

import httpx

logger = logging.getLogger(__name__)


class NodeRole(Enum):
    """Node role in the network hierarchy"""
    MASTER = "master"      # Level 0 - Primary knowledge source
    RELAY = "relay"        # Level 5 - Regional relay node
    EDGE = "edge"          # Level X - Edge cache node
    PEER = "peer"          # Standard peer node


class PeerManager:
    """
    Manages peer discovery, connections, and synchronization.

    Coordinates between:
    - TrackerProtocol (HTTP tracker client)
    - DHTDiscovery (decentralized peer finding)
    - P2PWireProtocol (TCP connections)
    - TorrentPieceCache (piece storage)
    """

    def __init__(
        self,
        peer_id: str,
        wire_protocol,        # P2PWireProtocol instance
        tracker_protocol,     # TrackerProtocol instance
        dht_discovery,        # DHTDiscovery instance
        torrent_cache,        # TorrentPieceCache instance
        rag_server=None,      # TrinityRAGServer instance (optional)
        node_role: NodeRole = NodeRole.PEER,
        listen_port: int = 6881,
        announce_ip: str = "127.0.0.1"
    ):
        self.peer_id = peer_id
        self.wire = wire_protocol
        self.tracker = tracker_protocol
        self.dht = dht_discovery
        self.cache = torrent_cache
        self.rag_server = rag_server
        self.node_role = node_role
        self.listen_port = listen_port
        self.announce_ip = announce_ip

        # Connected peers state
        self.connected_peers: Dict[str, Dict[str, Any]] = {}  # peer_id -> info
        self.peer_bitfields: Dict[str, Dict[str, List[bool]]] = {}  # peer_id -> {info_hash -> bitfield}

        # Sync state
        self._known_hashes: Set[str] = set()  # All info_hashes we know about
        self._last_sync: float = 0
        self._sync_interval: float = 30.0  # seconds

        # Background tasks
        self._running = False
        self._discovery_task: Optional[asyncio.Task] = None
        self._sync_task: Optional[asyncio.Task] = None
        self._health_task: Optional[asyncio.Task] = None

        # Callbacks
        self._on_new_knowledge: Optional[Callable] = None

        logger.info(f"PeerManager initialized: role={node_role.value}, "
                    f"peer_id={peer_id[:8]}..., port={listen_port}")

    async def start(self):
        """Start all background loops"""
        self._running = True

        # Initialize known hashes from cache
        self._known_hashes = set(self.cache.get_all_info_hashes())

        # Start background tasks
        self._discovery_task = asyncio.create_task(self._discovery_loop())
        self._sync_task = asyncio.create_task(self._sync_loop())
        self._health_task = asyncio.create_task(self._health_loop())

        logger.info(f"PeerManager started ({len(self._known_hashes)} known hashes)")

    async def stop(self):
        """Stop all background loops"""
        self._running = False
        for task in [self._discovery_task, self._sync_task, self._health_task]:
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        logger.info("PeerManager stopped")

    def set_on_new_knowledge(self, callback: Callable):
        """Set callback for when new knowledge is received from peers"""
        self._on_new_knowledge = callback

    # ============== Peer Discovery ==============

    async def discover_peers(self, info_hash: Optional[str] = None):
        """
        Discover peers via tracker and DHT.

        Args:
            info_hash: Optional specific hash to discover peers for.
                       If None, announces all known hashes.
        """
        hashes = [info_hash] if info_hash else list(self._known_hashes)

        for ih in hashes:
            try:
                # Announce to tracker
                peers = await self.tracker.announce(
                    info_hash=ih,
                    peer_id=self.peer_id,
                    port=self.listen_port,
                    event="started"
                )

                # Connect to discovered peers
                for peer_info in peers:
                    pid = peer_info.get('peer_id', '')
                    if pid and pid != self.peer_id and pid not in self.connected_peers:
                        addr = peer_info.get('ip', '')
                        port = peer_info.get('port', 0)
                        if addr and port:
                            await self._connect_to_peer(pid, addr, port)

            except Exception as e:
                logger.error(f"Discovery failed for {ih[:16]}...: {e}")

        # Also try DHT discovery
        try:
            closest = self.dht.find_closest_nodes(self.peer_id)
            for node in closest:
                nid = node.get('node_id', '')
                if nid and nid != self.peer_id and nid not in self.connected_peers:
                    addr = node.get('address', '')
                    port = node.get('port', 0)
                    if addr and port:
                        await self._connect_to_peer(nid, addr, port)
        except Exception as e:
            logger.debug(f"DHT discovery error: {e}")

    async def _connect_to_peer(self, peer_id: str, address: str, port: int):
        """Connect to a discovered peer"""
        try:
            success = await self.wire.connect_to_peer(address, port)
            if success:
                self.connected_peers[peer_id] = {
                    'address': address,
                    'port': port,
                    'connected_at': time.time(),
                    'last_active': time.time()
                }
                logger.info(f"Connected to peer {peer_id[:8]}... at {address}:{port}")

                # Send our bitfield after connecting
                await self._send_bitfield(peer_id)
        except Exception as e:
            logger.debug(f"Failed to connect to {peer_id[:8]}...: {e}")

    async def connect_manual(self, address: str, port: int) -> bool:
        """Manually connect to a peer by address:port"""
        try:
            success = await self.wire.connect_to_peer(address, port)
            if success:
                logger.info(f"Manually connected to {address}:{port}")
            return success
        except Exception as e:
            logger.error(f"Manual connect failed to {address}:{port}: {e}")
            return False

    # ============== Sync ==============

    async def sync_with_peers(self):
        """Broadcast sync status to all connected peers"""
        from p2p.protocol import P2PMessage, P2PMessageType

        # Build our current hash list
        our_hashes = list(self._known_hashes)

        sync_msg = P2PMessage(
            msg_type=P2PMessageType.SYNC_STATUS,
            payload={
                'hashes': our_hashes,
                'role': self.node_role.value,
                'piece_count': len(self.cache.available_pieces)
            },
            peer_id=self.peer_id
        )

        await self.wire.broadcast(sync_msg)
        self._last_sync = time.time()

    async def handle_sync_status(self, message, peer_id: str):
        """Handle incoming sync status from a peer"""
        from p2p.protocol import P2PMessage, P2PMessageType

        peer_hashes = set(message.payload.get('hashes', []))
        our_hashes = self._known_hashes

        # Find hashes we don't have
        new_hashes = peer_hashes - our_hashes

        if new_hashes:
            # Send ACK with the new hashes we want
            ack_msg = P2PMessage(
                msg_type=P2PMessageType.SYNC_ACK,
                payload={
                    'wanted_hashes': list(new_hashes),
                    'ack': True
                },
                peer_id=self.peer_id
            )
            await self.wire.send_to_peer(peer_id, ack_msg)
            logger.info(f"Requesting {len(new_hashes)} new hashes from {peer_id[:8]}...")
        else:
            # Everything in sync
            ack_msg = P2PMessage(
                msg_type=P2PMessageType.SYNC_ACK,
                payload={'wanted_hashes': [], 'ack': True},
                peer_id=self.peer_id
            )
            await self.wire.send_to_peer(peer_id, ack_msg)

    async def handle_sync_ack(self, message, peer_id: str):
        """Handle sync ACK — peer wants specific hashes from us"""
        from p2p.protocol import P2PMessage, P2PMessageType

        wanted = message.payload.get('wanted_hashes', [])

        for info_hash in wanted:
            meta = self.cache.get_torrent_meta(info_hash)
            if meta:
                # Send torrent meta + pieces
                offer_msg = P2PMessage(
                    msg_type=P2PMessageType.KNOWLEDGE_OFFER,
                    payload={
                        'info_hash': info_hash,
                        'torrent_meta': meta.to_dict(),
                        'piece_count': len(meta.piece_ids)
                    },
                    peer_id=self.peer_id
                )
                await self.wire.send_to_peer(peer_id, offer_msg)

    async def _send_bitfield(self, peer_id: str):
        """Send our bitfield to a peer for all known torrents"""
        from p2p.protocol import P2PMessage, P2PMessageType

        bitfields = {}
        for info_hash in self._known_hashes:
            bf = self.cache.get_bitfield(info_hash)
            if bf:
                bitfields[info_hash] = bf

        if bitfields:
            bf_msg = P2PMessage(
                msg_type=P2PMessageType.BITFIELD,
                payload={'bitfields': bitfields},
                peer_id=self.peer_id
            )
            await self.wire.send_to_peer(peer_id, bf_msg)

    # ============== Piece Exchange ==============

    async def request_pieces(self, peer_id: str, info_hash: str):
        """Request missing pieces for a torrent from a specific peer"""
        from p2p.protocol import P2PMessage, P2PMessageType

        missing = self.cache.get_missing_pieces(info_hash)

        for piece_id in missing:
            req_msg = P2PMessage(
                msg_type=P2PMessageType.REQUEST,
                payload={
                    'info_hash': info_hash,
                    'piece_id': piece_id
                },
                peer_id=self.peer_id
            )
            await self.wire.send_to_peer(peer_id, req_msg)

    async def handle_piece_request(self, message, peer_id: str):
        """Handle incoming piece request — send piece data"""
        from p2p.protocol import P2PMessage, P2PMessageType

        piece_id = message.payload.get('piece_id', '')
        info_hash = message.payload.get('info_hash', '')

        piece_data = self.cache.get_piece(piece_id)
        if piece_data:
            # Send piece
            piece_msg = P2PMessage(
                msg_type=P2PMessageType.PIECE,
                payload={
                    'info_hash': info_hash,
                    'piece_id': piece_id,
                    'data': piece_data.hex()  # Send as hex string for JSON compat
                },
                peer_id=self.peer_id
            )
            await self.wire.send_to_peer(peer_id, piece_msg)
            logger.debug(f"Sent piece {piece_id[:16]}... to {peer_id[:8]}...")
        else:
            logger.warning(f"Requested piece {piece_id[:16]}... not found")

    async def handle_piece_received(self, message, peer_id: str):
        """Handle incoming piece data — store in cache"""
        piece_id = message.payload.get('piece_id', '')
        data_hex = message.payload.get('data', '')
        info_hash = message.payload.get('info_hash', '')

        try:
            data = bytes.fromhex(data_hex)
            stored = self.cache.store_piece(piece_id, data)

            if stored:
                logger.info(f"Received piece {piece_id[:16]}... from {peer_id[:8]}...")

                # Check if torrent is now complete
                if info_hash and self.cache.is_complete(info_hash):
                    logger.info(f"Torrent {info_hash[:16]}... is now complete!")
                    await self._on_torrent_complete(info_hash)
        except Exception as e:
            logger.error(f"Failed to store piece: {e}")

    async def _on_torrent_complete(self, info_hash: str):
        """Called when all pieces of a torrent have been received"""
        chunk_data = self.cache.reassemble_chunk(info_hash)
        if chunk_data and self._on_new_knowledge:
            await self._on_new_knowledge(chunk_data)

        # Announce completion to tracker
        try:
            await self.tracker.announce(
                info_hash=info_hash,
                peer_id=self.peer_id,
                port=self.listen_port,
                event="completed"
            )
        except Exception:
            pass

    # ============== Knowledge on this node ==============

    async def add_local_knowledge(self, chunk_id: str, content: str,
                                  vector_bytes: Optional[bytes] = None,
                                  metadata: Optional[Dict] = None) -> str:
        """
        Add local knowledge and make it available on the network.

        Returns:
            info_hash of the new torrent
        """
        info_hash = self.cache.add_chunk(chunk_id, content, vector_bytes, metadata)
        self._known_hashes.add(info_hash)

        # Announce to tracker
        try:
            await self.tracker.announce(
                info_hash=info_hash,
                peer_id=self.peer_id,
                port=self.listen_port,
                event="started"
            )
        except Exception as e:
            logger.warning(f"Failed to announce {info_hash[:16]}...: {e}")

        # Propagate to connected peers based on role
        if self.node_role == NodeRole.MASTER:
            # Master: propagate to all peers with high priority
            await self.sync_with_peers()

        return info_hash

    # ============== Background Loops ==============

    async def _discovery_loop(self):
        """Periodically discover new peers"""
        while self._running:
            try:
                await asyncio.sleep(60)  # Every 60 seconds
                await self.discover_peers()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Discovery loop error: {e}")
                await asyncio.sleep(10)

    async def _sync_loop(self):
        """Periodically sync with connected peers"""
        while self._running:
            try:
                await asyncio.sleep(self._sync_interval)
                if self.connected_peers:
                    await self.sync_with_peers()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Sync loop error: {e}")
                await asyncio.sleep(10)

    async def _health_loop(self):
        """Monitor peer connection health"""
        while self._running:
            try:
                await asyncio.sleep(120)  # Every 2 minutes
                # Check for dead peers
                dead_peers = []
                for pid, info in self.connected_peers.items():
                    if pid not in self.wire.peers:
                        dead_peers.append(pid)

                for pid in dead_peers:
                    del self.connected_peers[pid]
                    self.peer_bitfields.pop(pid, None)
                    logger.info(f"Removed dead peer {pid[:8]}...")

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Health loop error: {e}")

    # ============== Status ==============

    def get_connected_peers(self) -> List[Dict[str, Any]]:
        """Get list of connected peers with their info"""
        result = []
        for pid, info in self.connected_peers.items():
            result.append({
                'peer_id': pid,
                'address': info.get('address', ''),
                'port': info.get('port', 0),
                'connected_at': info.get('connected_at', 0),
                'last_active': info.get('last_active', 0)
            })
        return result

    def get_status(self) -> Dict[str, Any]:
        """Get full node status"""
        return {
            'peer_id': self.peer_id,
            'role': self.node_role.value,
            'listen_port': self.listen_port,
            'connected_peers': len(self.connected_peers),
            'known_hashes': len(self._known_hashes),
            'available_pieces': len(self.cache.available_pieces),
            'cache_stats': self.cache.get_stats(),
            'peers': self.get_connected_peers()
        }
