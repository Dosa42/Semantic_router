#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  𐰉𐰆𐰕𐰴𐰆𐰺𐱃  ·  𐰚𐰺𐰞  ·  UAGL 3.0                                            ║
║                                                                              ║
║  T R I N I T Y   C O R E  —  RAG HAFİZA MOTORU                             ║
║  UAGL_BROTHERHOOD_TEAM · TRINITY/trinity_core.py                            ║
║                                                                              ║
║  Entegrasyon:                                                                ║
║  - FAISS  → Vektör similarity search                                        ║
║  - SQLite → Yapısal metadata + tier yönetimi                                ║
║  - SDCK Canon → Deterministik sınıflandırma                                 ║
║  - UAGL g-vektörleri → TESSA tier mapping                                   ║
║  - Guardian κ → Chunk güven skoru                                           ║
║                                                                              ║
║  HTTP API (:7700):                                                           ║
║    POST /ingest    → Bilgi gir                                               ║
║    POST /query     → Semantic arama                                          ║
║    POST /context   → LLM için hazır context                                 ║
║    GET  /stats     → İstatistikler                                           ║
║    POST /save      → FAISS index diske kaydet                               ║
║    GET  /health    → Sağlık kontrolü                                        ║
║                                                                              ║
║  ÇALIŞTIR:  python TRINITY/trinity_core.py [--port 7700]                   ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import argparse
import asyncio
import hashlib
import json
import logging
import pickle
import sqlite3
import sys
import time
import zlib
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union

import numpy as np

# ── FastAPI ────────────────────────────────────────────────────
try:
    from fastapi import FastAPI, HTTPException
    from fastapi.middleware.cors import CORSMiddleware
    from pydantic import BaseModel
    import uvicorn
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False

log = logging.getLogger('TrinityCore')

# ══════════════════════════════════════════════════════════════════
# UAGL TESSA — g-vektör → tier mapping
# ══════════════════════════════════════════════════════════════════
TESSA_TABLE = [
    (0.85, 'BENEFIT_ACCEL_EFF', 'ALLOW',   'hot'),
    (0.75, 'BENEFIT_ACCEL',     'ALLOW',   'hot'),
    (0.65, 'BENEFIT_STABLE_EFF','ALLOW',   'hot'),
    (0.55, 'BENEFIT_STABLE',    'ALLOW',   'warm'),
    (0.45, 'BENEFIT_DECAY',     'MONITOR', 'warm'),
    (0.35, 'PROMOTE',           'MONITOR', 'warm'),
    (0.25, 'NEUTRAL_STABLE',    'MONITOR', 'cold'),
    (0.15, 'NEUTRAL_COLLAPSE',  'MONITOR', 'cold'),
    (0.10, 'HOSTILE_STABLE',    'MONITOR', 'cold'),
    (0.05, 'HOSTILE_UNSTABLE',  'ISOLATE', 'frozen'),
    (0.00, 'HOSTILE_ACCEL',     'ISOLATE', 'frozen'),
]

def kappa_from_gvec(g1: float, g2: float, g3: float, g4: float = 0.0) -> float:
    return max(0.0, min(1.0, 0.35*g1 + 0.25*g2 + 0.28*g3 + 0.12*g4))

def tessa_classify(kappa: float) -> dict:
    for threshold, name, perm, tier in TESSA_TABLE:
        if kappa > threshold:
            return {'kappa': kappa, 'name': name, 'permission': perm, 'tier': tier}
    return {'kappa': kappa, 'name': 'HOSTILE_ACCEL', 'permission': 'ISOLATE', 'tier': 'frozen'}


# ══════════════════════════════════════════════════════════════════
# DATA CLASSES
# ══════════════════════════════════════════════════════════════════
class StorageTier(Enum):
    HOT    = "hot"
    WARM   = "warm"
    COLD   = "cold"
    FROZEN = "frozen"

class ConfidenceLevel(Enum):
    CERTAIN   = "certain"
    HIGH      = "high"
    MEDIUM    = "medium"
    LOW       = "low"
    UNCERTAIN = "uncertain"

@dataclass
class SemanticVector:
    data: np.ndarray
    dimension: int = 384
    norm: float = 0.0

    def __post_init__(self):
        if self.norm == 0.0 and self.data is not None:
            n = np.linalg.norm(self.data)
            self.norm = float(n) if n > 0 else 1.0

    def to_bytes(self) -> bytes:
        return pickle.dumps(self.data)

    @classmethod
    def from_bytes(cls, data: bytes) -> 'SemanticVector':
        arr = pickle.loads(data)
        return cls(data=arr, dimension=len(arr))

@dataclass
class KnowledgeChunk:
    chunk_id:     str
    content:      str
    vector:       Optional[SemanticVector] = None
    tier:         StorageTier = StorageTier.WARM
    confidence:   ConfidenceLevel = ConfidenceLevel.MEDIUM
    source:       str = "hub"
    session_id:   str = ""
    kappa:        float = 0.5
    tessa_name:   str = "BENEFIT_STABLE"
    access_count: int = 0
    last_accessed: float = field(default_factory=time.time)
    created_at:   float = field(default_factory=time.time)
    metadata:     Dict[str, Any] = field(default_factory=dict)

    def compute_hash(self) -> str:
        return hashlib.sha256(self.content.encode()).hexdigest()[:16]

@dataclass
class SDCKClassification:
    tier:       StorageTier
    confidence: ConfidenceLevel
    score:      float
    reasoning:  str
    timestamp:  float = field(default_factory=time.time)


# ══════════════════════════════════════════════════════════════════
# SDCK CANON — Deterministik sınıflandırma
# ══════════════════════════════════════════════════════════════════
class SDCKCanon:
    def __init__(self, epsilon: float = 0.1):
        self.epsilon = epsilon
        self._history: List[SDCKClassification] = []

    def classify(self, chunk: KnowledgeChunk,
                 context: Optional[Dict[str, Any]] = None) -> SDCKClassification:
        score = self._score(chunk, context)
        tier, confidence = self._map_score(score)
        result = SDCKClassification(
            tier=tier,
            confidence=confidence,
            score=score,
            reasoning=self._reason(chunk, score, context),
        )
        self._history.append(result)
        return result

    def _score(self, chunk: KnowledgeChunk, context: Optional[dict]) -> float:
        s = 0.0
        content = chunk.content.lower()
        # Uzunluk
        if len(content) > 500:  s += 0.25
        elif len(content) > 100: s += 0.15
        else:                    s += 0.05
        # Erişim sıklığı
        s += min(chunk.access_count * 0.05, 0.3)
        # Kaynak
        src_weights = {'guardian': 0.25, 'kral': 0.2, 'hub': 0.15, 'imperial': 0.15}
        s += src_weights.get(chunk.source.lower(), 0.1)
        # Kappa skoru doğrudan katkı
        s += chunk.kappa * 0.3
        return min(s, 1.0)

    def _map_score(self, score: float) -> Tuple[StorageTier, ConfidenceLevel]:
        if score >= 0.75:   return StorageTier.HOT,    ConfidenceLevel.CERTAIN
        elif score >= 0.55: return StorageTier.HOT,    ConfidenceLevel.HIGH
        elif score >= 0.40: return StorageTier.WARM,   ConfidenceLevel.MEDIUM
        elif score >= 0.25: return StorageTier.COLD,   ConfidenceLevel.LOW
        else:               return StorageTier.FROZEN, ConfidenceLevel.UNCERTAIN

    def _reason(self, chunk: KnowledgeChunk, score: float, context: Optional[dict]) -> str:
        return (f"score={score:.3f} | kappa={chunk.kappa:.3f} | "
                f"src={chunk.source} | len={len(chunk.content)} | "
                f"access={chunk.access_count}")

    def should_consolidate(self, chunk: KnowledgeChunk) -> bool:
        age = time.time() - chunk.last_accessed
        return age > 86400 and chunk.access_count < 3


# ══════════════════════════════════════════════════════════════════
# SEMANTIC FORCE ENGINE — Embedding
# ══════════════════════════════════════════════════════════════════
class SemanticForceEngine:
    def __init__(self, dimension: int = 384, model_name: str = "all-MiniLM-L6-v2"):
        self.dimension = dimension
        self.model_name = model_name
        self._model = None
        self._load_model()

    def _load_model(self):
        try:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(self.model_name)
            log.info(f"SentenceTransformer yüklendi: {self.model_name}")
        except ImportError:
            log.warning("sentence-transformers yok — deterministik hash vektörü kullanılıyor")
            self._model = None

    async def embed(self, text: str) -> SemanticVector:
        if self._model:
            loop = asyncio.get_event_loop()
            arr = await loop.run_in_executor(
                None, lambda: self._model.encode(text, normalize_embeddings=True)
            )
            return SemanticVector(data=arr.astype(np.float32), dimension=self.dimension)
        # Fallback: deterministik hash vektörü
        h = hashlib.sha512(text.encode()).digest()
        arr = np.frombuffer(h * (self.dimension // 64 + 1), dtype=np.uint8)[:self.dimension].astype(np.float32)
        arr = arr / 255.0
        norm = np.linalg.norm(arr)
        if norm > 0: arr /= norm
        return SemanticVector(data=arr, dimension=self.dimension)

    async def embed_batch(self, texts: List[str]) -> List[SemanticVector]:
        return [await self.embed(t) for t in texts]

    def compute_similarity(self, v1: SemanticVector, v2: SemanticVector) -> float:
        if v1.data is None or v2.data is None:
            return 0.0
        return float(np.dot(v1.data, v2.data) / (v1.norm * v2.norm + 1e-8))


# ══════════════════════════════════════════════════════════════════
# FAISS INDEX
# ══════════════════════════════════════════════════════════════════
class FAISSIndex:
    def __init__(self, dimension: int = 384, index_type: str = "Flat"):
        self.dimension = dimension
        self._index = None
        self._id_map: List[str] = []
        self._init_index(index_type)

    def _init_index(self, index_type: str):
        try:
            import faiss
            self._index = faiss.IndexFlatIP(self.dimension)
            log.info(f"FAISS index başlatıldı (dim={self.dimension})")
        except ImportError:
            log.warning("faiss-cpu yok — numpy linear search kullanılıyor")
            self._index = None
            self._vectors: Dict[str, np.ndarray] = {}

    def add(self, chunk_id: str, vector: np.ndarray) -> int:
        if self._index is not None:
            import faiss
            v = vector.reshape(1, -1).astype(np.float32)
            self._index.add(v)
        else:
            self._vectors[chunk_id] = vector.astype(np.float32)
        self._id_map.append(chunk_id)
        return len(self._id_map) - 1

    def search(self, query_vector: np.ndarray, k: int = 10) -> List[Tuple[str, float]]:
        if not self._id_map:
            return []
        k = min(k, len(self._id_map))
        if self._index is not None:
            q = query_vector.reshape(1, -1).astype(np.float32)
            scores, indices = self._index.search(q, k)
            results = []
            for score, idx in zip(scores[0], indices[0]):
                if 0 <= idx < len(self._id_map):
                    results.append((self._id_map[idx], float(score)))
            return results
        else:
            # Linear search fallback
            q = query_vector.astype(np.float32)
            q_norm = np.linalg.norm(q)
            if q_norm > 0: q /= q_norm
            scores = []
            for cid, v in self._vectors.items():
                n = np.linalg.norm(v)
                if n > 0:
                    scores.append((cid, float(np.dot(q, v / n))))
            scores.sort(key=lambda x: x[1], reverse=True)
            return scores[:k]

    def save(self, filepath: str):
        data = {'id_map': self._id_map}
        if self._index is not None:
            import faiss
            faiss.write_index(self._index, filepath + '.index')
        else:
            data['vectors'] = {k: v.tolist() for k, v in getattr(self, '_vectors', {}).items()}
        with open(filepath + '.meta', 'w') as f:
            json.dump(data, f)
        log.info(f"FAISS index kaydedildi: {filepath}")

    def load(self, filepath: str):
        meta_path = filepath + '.meta'
        if not Path(meta_path).exists():
            return
        with open(meta_path) as f:
            data = json.load(f)
        self._id_map = data.get('id_map', [])
        if self._index is not None:
            index_path = filepath + '.index'
            if Path(index_path).exists():
                import faiss
                self._index = faiss.read_index(index_path)
        else:
            self._vectors = {k: np.array(v, dtype=np.float32)
                             for k, v in data.get('vectors', {}).items()}
        log.info(f"FAISS index yüklendi: {len(self._id_map)} vektör")

    @property
    def ntotal(self) -> int:
        return len(self._id_map)


# ══════════════════════════════════════════════════════════════════
# METADATA STORE — SQLite
# ══════════════════════════════════════════════════════════════════
class TrinityMetadataStore:
    def __init__(self, db_path: str = "./trinity_metadata.db"):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS chunks (
                    chunk_id      TEXT PRIMARY KEY,
                    content       TEXT NOT NULL,
                    vector_blob   BLOB,
                    tier          TEXT DEFAULT 'warm',
                    confidence    TEXT DEFAULT 'medium',
                    source        TEXT DEFAULT 'hub',
                    session_id    TEXT DEFAULT '',
                    kappa         REAL DEFAULT 0.5,
                    tessa_name    TEXT DEFAULT 'BENEFIT_STABLE',
                    access_count  INTEGER DEFAULT 0,
                    last_accessed REAL,
                    created_at    REAL,
                    metadata_json TEXT DEFAULT '{}'
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS query_log (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    query_text TEXT,
                    results    TEXT,
                    ts         REAL
                )
            """)
            conn.commit()

    def store_chunk(self, chunk: KnowledgeChunk) -> bool:
        try:
            with sqlite3.connect(self.db_path) as conn:
                vblob = chunk.vector.to_bytes() if chunk.vector else None
                conn.execute("""
                    INSERT OR REPLACE INTO chunks
                    (chunk_id, content, vector_blob, tier, confidence, source,
                     session_id, kappa, tessa_name, access_count, last_accessed,
                     created_at, metadata_json)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    chunk.chunk_id, chunk.content, vblob,
                    chunk.tier.value, chunk.confidence.value,
                    chunk.source, chunk.session_id,
                    chunk.kappa, chunk.tessa_name,
                    chunk.access_count, chunk.last_accessed,
                    chunk.created_at,
                    json.dumps(chunk.metadata),
                ))
                conn.commit()
            return True
        except Exception as e:
            log.error(f"store_chunk hatası: {e}")
            return False

    def get_chunk(self, chunk_id: str) -> Optional[KnowledgeChunk]:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM chunks WHERE chunk_id=?", (chunk_id,)
            ).fetchone()
        return self._row_to_chunk(row) if row else None

    def get_chunks_by_tier(self, tier: StorageTier, limit: int = 100) -> List[KnowledgeChunk]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT * FROM chunks WHERE tier=? LIMIT ?",
                (tier.value, limit)
            ).fetchall()
        return [self._row_to_chunk(r) for r in rows]

    def update_access(self, chunk_id: str):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                UPDATE chunks SET access_count=access_count+1, last_accessed=?
                WHERE chunk_id=?
            """, (time.time(), chunk_id))
            conn.commit()

    def get_all_chunk_ids(self) -> List[str]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute("SELECT chunk_id FROM chunks").fetchall()
        return [r[0] for r in rows]

    def get_stats(self) -> dict:
        with sqlite3.connect(self.db_path) as conn:
            total = conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
            by_tier = dict(conn.execute(
                "SELECT tier, COUNT(*) FROM chunks GROUP BY tier"
            ).fetchall())
            avg_kappa = conn.execute("SELECT AVG(kappa) FROM chunks").fetchone()[0] or 0.0
        return {'total_chunks': total, 'by_tier': by_tier,
                'avg_kappa': round(avg_kappa, 4)}

    def _row_to_chunk(self, row) -> KnowledgeChunk:
        (chunk_id, content, vblob, tier, confidence, source, session_id,
         kappa, tessa_name, access_count, last_accessed, created_at, meta_json) = row
        vec = SemanticVector.from_bytes(vblob) if vblob else None
        return KnowledgeChunk(
            chunk_id=chunk_id, content=content, vector=vec,
            tier=StorageTier(tier), confidence=ConfidenceLevel(confidence),
            source=source, session_id=session_id,
            kappa=kappa or 0.5, tessa_name=tessa_name or 'BENEFIT_STABLE',
            access_count=access_count or 0,
            last_accessed=last_accessed or time.time(),
            created_at=created_at or time.time(),
            metadata=json.loads(meta_json or '{}'),
        )


# ══════════════════════════════════════════════════════════════════
# TRINITY RAG SERVER — Ana motor
# ══════════════════════════════════════════════════════════════════
class TrinityRAGServer:
    """
    UAGL_BROTHERHOOD_TEAM Trinity RAG motoru.
    FAISS + SQLite + SDCK Canon + UAGL TESSA entegrasyonu.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.dimension   = self.config.get('vector_dimension', 384)
        self.db_path     = self.config.get('db_path',    './TRINITY/storage/trinity_metadata.db')
        self.index_path  = self.config.get('index_path', './TRINITY/storage/trinity_vectors')
        self.model_name  = self.config.get('model_name', 'all-MiniLM-L6-v2')

        self.semantic_engine = SemanticForceEngine(
            dimension=self.dimension, model_name=self.model_name
        )
        self.faiss_index    = FAISSIndex(dimension=self.dimension)
        self.metadata_store = TrinityMetadataStore(db_path=self.db_path)
        self.sdck_canon     = SDCKCanon(epsilon=self.config.get('epsilon', 0.1))

        self._hot_cache: Dict[str, KnowledgeChunk] = {}
        self._lock = asyncio.Lock()
        self._consolidation_task: Optional[asyncio.Task] = None
        self._running = False

    async def start(self):
        self._running = True
        self.load()
        self._consolidation_task = asyncio.create_task(self._consolidation_loop())
        log.info(f"TrinityRAGServer başlatıldı — {self.metadata_store.get_stats()}")

    async def stop(self):
        self._running = False
        if self._consolidation_task:
            self._consolidation_task.cancel()
        self.save()
        log.info("TrinityRAGServer durduruldu.")

    async def ingest(
        self,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
        source: str = "hub",
        session_id: str = "",
        kappa: Optional[float] = None,
        g1: float = 0.7, g2: float = 0.5, g3: float = 0.8, g4: float = 0.2,
    ) -> str:
        """Bilgiyi RAG'a ekler. chunk_id döner."""
        meta = metadata or {}
        # κ hesapla
        if kappa is None:
            kappa = kappa_from_gvec(g1, g2, g3, g4)
        tessa = tessa_classify(kappa)

        chunk_id = hashlib.sha256(
            f"{content}{source}{session_id}".encode()
        ).hexdigest()[:24]

        vector = await self.semantic_engine.embed(content)

        chunk = KnowledgeChunk(
            chunk_id=chunk_id,
            content=content,
            vector=vector,
            tier=StorageTier(tessa['tier']),
            confidence=ConfidenceLevel.HIGH,
            source=source,
            session_id=session_id,
            kappa=kappa,
            tessa_name=tessa['name'],
            metadata=meta,
        )

        classification = self.sdck_canon.classify(chunk)
        chunk.tier = classification.tier

        async with self._lock:
            # FAISS
            if not any(cid == chunk_id for cid in self.faiss_index._id_map):
                self.faiss_index.add(chunk_id, vector.data)
            # SQLite
            self.metadata_store.store_chunk(chunk)
            # Hot cache
            if chunk.tier == StorageTier.HOT:
                self._hot_cache[chunk_id] = chunk
                if len(self._hot_cache) > self.config.get('hot_cache_size', 500):
                    oldest = min(self._hot_cache, key=lambda k: self._hot_cache[k].last_accessed)
                    del self._hot_cache[oldest]

        log.debug(f"Ingest: {chunk_id[:12]}… tier={chunk.tier.value} κ={kappa:.3f}")
        return chunk_id

    async def query(
        self,
        query_text: str,
        k: int = 5,
        tier_filter: Optional[str] = None,
        min_kappa: float = 0.0,
    ) -> List[Dict[str, Any]]:
        """Semantic arama. Skorlu chunk listesi döner."""
        query_vec = await self.semantic_engine.embed(query_text)
        raw = self.faiss_index.search(query_vec.data, k=min(k * 3, 50))

        results = []
        seen = set()
        for chunk_id, score in raw:
            if chunk_id in seen:
                continue
            seen.add(chunk_id)

            # Hot cache önce
            chunk = self._hot_cache.get(chunk_id)
            if chunk is None:
                chunk = self.metadata_store.get_chunk(chunk_id)
            if chunk is None:
                continue

            if tier_filter and chunk.tier.value != tier_filter:
                continue
            if chunk.kappa < min_kappa:
                continue

            self.metadata_store.update_access(chunk_id)
            chunk.access_count += 1
            if chunk_id in self._hot_cache:
                self._hot_cache[chunk_id].access_count += 1

            results.append({
                'chunk_id':   chunk_id,
                'content':    chunk.content,
                'score':      round(score, 4),
                'tier':       chunk.tier.value,
                'kappa':      round(chunk.kappa, 4),
                'tessa':      chunk.tessa_name,
                'source':     chunk.source,
                'session_id': chunk.session_id,
                'metadata':   chunk.metadata,
            })
            if len(results) >= k:
                break

        return results

    async def get_context_for_llm(self, query_text: str, k: int = 5) -> str:
        """LLM prompt'a eklenecek format edilmiş context döner."""
        results = await self.query(query_text, k=k)
        if not results:
            return "Trinity RAG: İlgili bilgi bulunamadı."
        lines = [f"[Trinity RAG Context — {len(results)} chunk]\n"]
        for i, r in enumerate(results, 1):
            lines.append(
                f"[{i}] kaynak={r['source']} | κ={r['kappa']} | tier={r['tier']}\n"
                f"     {r['content'][:500]}\n"
            )
        return "\n".join(lines)

    def get_stats(self) -> dict:
        db_stats = self.metadata_store.get_stats()
        return {
            'version':       '3.0-UAGL',
            'faiss_vectors': self.faiss_index.ntotal,
            'hot_cache':     len(self._hot_cache),
            **db_stats,
        }

    def save(self):
        Path(self.index_path).parent.mkdir(parents=True, exist_ok=True)
        self.faiss_index.save(self.index_path)

    def load(self):
        self.faiss_index.load(self.index_path)

    async def _consolidation_loop(self):
        while self._running:
            await asyncio.sleep(3600)  # Her saat
            try:
                hot_chunks = self.metadata_store.get_chunks_by_tier(StorageTier.HOT, 200)
                for chunk in hot_chunks:
                    if self.sdck_canon.should_consolidate(chunk):
                        chunk.tier = StorageTier.WARM
                        self.metadata_store.store_chunk(chunk)
                        self._hot_cache.pop(chunk.chunk_id, None)
                self.save()
            except Exception as e:
                log.error(f"Consolidation hatası: {e}")


# ══════════════════════════════════════════════════════════════════
# HTTP API — FastAPI wrapper
# ══════════════════════════════════════════════════════════════════
def build_api(rag: TrinityRAGServer) -> 'FastAPI':
    app = FastAPI(
        title="Trinity Core RAG",
        description="𐰚𐰺𐰞 · UAGL_BROTHERHOOD_TEAM · Trinity RAG HTTP API",
        version="3.0-UAGL",
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    class IngestRequest(BaseModel):
        content: str
        metadata: dict = {}
        source: str = "hub"
        session_id: str = ""
        kappa: Optional[float] = None
        g1: float = 0.7
        g2: float = 0.5
        g3: float = 0.8
        g4: float = 0.2

    class QueryRequest(BaseModel):
        query_text: str
        k: int = 5
        tier_filter: Optional[str] = None
        min_kappa: float = 0.0

    class ContextRequest(BaseModel):
        query_text: str
        k: int = 5

    @app.on_event("startup")
    async def startup():
        await rag.start()

    @app.on_event("shutdown")
    async def shutdown():
        await rag.stop()

    @app.get("/health")
    async def health():
        stats = rag.get_stats()
        return {"status": "ok", "service": "Trinity Core RAG", **stats}

    @app.post("/ingest")
    async def ingest(req: IngestRequest):
        chunk_id = await rag.ingest(
            content=req.content,
            metadata=req.metadata,
            source=req.source,
            session_id=req.session_id,
            kappa=req.kappa,
            g1=req.g1, g2=req.g2, g3=req.g3, g4=req.g4,
        )
        return {"chunk_id": chunk_id, "status": "ingested"}

    @app.post("/query")
    async def query(req: QueryRequest):
        results = await rag.query(
            query_text=req.query_text,
            k=req.k,
            tier_filter=req.tier_filter,
            min_kappa=req.min_kappa,
        )
        return {"query": req.query_text, "k": req.k, "results": results}

    @app.post("/context")
    async def context(req: ContextRequest):
        ctx = await rag.get_context_for_llm(req.query_text, k=req.k)
        return {"context": ctx}

    @app.get("/stats")
    async def stats():
        return rag.get_stats()

    @app.post("/save")
    async def save():
        rag.save()
        return {"status": "saved"}

    return app


# ══════════════════════════════════════════════════════════════════
# FACTORY
# ══════════════════════════════════════════════════════════════════
_instance: Optional[TrinityRAGServer] = None

def get_trinity_server(config: Optional[Dict[str, Any]] = None) -> TrinityRAGServer:
    global _instance
    if _instance is None:
        # Karargah config'dan yükle
        cfg_path = Path(__file__).parent.parent / 'KARARGAH' / 'karargah_config.json'
        base_cfg = {}
        if cfg_path.exists():
            with open(cfg_path) as f:
                full = json.load(f)
            paths = full.get('paths', {})
            base_dir = cfg_path.parent.parent
            base_cfg = {
                'db_path':    str(base_dir / paths.get('trinity_db',    'TRINITY/storage/trinity_metadata.db')),
                'index_path': str(base_dir / paths.get('trinity_index', 'TRINITY/storage/trinity_vectors')),
                **full.get('trinity', {}),
            }
        if config:
            base_cfg.update(config)
        _instance = TrinityRAGServer(config=base_cfg)
    return _instance


# ══════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════
if __name__ == '__main__':
    import argparse
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s  [TrinityCore]  %(levelname)s  %(message)s',
        datefmt='%H:%M:%S',
    )
    parser = argparse.ArgumentParser(description='Trinity Core RAG Server')
    parser.add_argument('--port', type=int, default=7700)
    parser.add_argument('--host', default='0.0.0.0')
    args = parser.parse_args()

    if not HAS_FASTAPI:
        log.error("fastapi veya uvicorn yüklü değil: pip install fastapi uvicorn")
        sys.exit(1)

    rag = get_trinity_server()
    app = build_api(rag)

    print(f"""
╔══════════════════════════════════════════════════════════╗
║  𐰚𐰺𐰞  ·  TRINITY CORE RAG  ·  UAGL 3.0                 ║
║  http://{args.host}:{args.port}                              ║
║                                                          ║
║  POST /ingest   → Bilgi gir                              ║
║  POST /query    → Semantic ara                           ║
║  POST /context  → LLM context                           ║
║  GET  /stats    → İstatistik                             ║
║  GET  /health   → Sağlık                                ║
╚══════════════════════════════════════════════════════════╝
""")
    uvicorn.run(app, host=args.host, port=args.port, log_level='warning')
