"""
UAGL_BROTHERHOOD_TEAM · TRINITY STORAGE MANAGER
=======================

Unified storage management:
- Read/Write/Storage permissions
- Tiered storage (Hot/Warm/Cold/Frozen)
- Compression en encryptie
- Backup en recovery
- Quota management

@author VEKIL-KAAN / SATEN
@version 3.0-UAGL-KARARGAH
"""

import asyncio
import hashlib
import json
import logging
import os
import shutil
import zlib
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from uuid import uuid4

logger = logging.getLogger(__name__)


class Permission(Enum):
    """Storage permissions"""
    READ = "read"
    WRITE = "write"
    DELETE = "delete"
    SHARE = "share"
    ADMIN = "admin"


class StorageTier(Enum):
    """Storage tiers"""
    HOT = "hot"       # SSD, direct access
    WARM = "warm"     # SSD, cached
    COLD = "cold"     # HDD, compressed
    FROZEN = "frozen" # Archive, encrypted


@dataclass
class StorageQuota:
    """Storage quota voor gebruiker"""
    user_id: str
    max_bytes: int = 10 * 1024 * 1024 * 1024  # 10 GB default
    used_bytes: int = 0
    max_files: int = 10000
    used_files: int = 0
    
    @property
    def available_bytes(self) -> int:
        return self.max_bytes - self.used_bytes
    
    @property
    def available_files(self) -> int:
        return self.max_files - self.used_files
    
    def can_store(self, size_bytes: int) -> bool:
        return size_bytes <= self.available_bytes and self.used_files < self.max_files


@dataclass
class StoredObject:
    """Stored object metadata"""
    id: str
    path: str
    size_bytes: int
    content_hash: str
    owner_id: str
    tier: StorageTier
    permissions: Dict[str, List[Permission]] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    accessed_at: datetime = field(default_factory=datetime.now)
    access_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    compressed: bool = False
    encrypted: bool = False
    tags: List[str] = field(default_factory=list)


class StorageManager:
    """
    Trinity Storage Manager
    
    Beheert:
    - File storage met permissions
    - Tiered storage
    - Compression/encryptie
    - Quota management
    """
    
    # Tier configuratie
    TIER_CONFIG = {
        StorageTier.HOT: {
            'path': 'hot',
            'compress': False,
            'encrypt': False,
            'max_age_days': 1
        },
        StorageTier.WARM: {
            'path': 'warm',
            'compress': False,
            'encrypt': False,
            'max_age_days': 7
        },
        StorageTier.COLD: {
            'path': 'cold',
            'compress': True,
            'encrypt': False,
            'max_age_days': 30
        },
        StorageTier.FROZEN: {
            'path': 'frozen',
            'compress': True,
            'encrypt': True,
            'max_age_days': 365
        }
    }
    
    def __init__(self, base_path: str = "./storage"):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        
        # Create tier directories
        for tier in StorageTier:
            tier_path = self.base_path / self.TIER_CONFIG[tier]['path']
            tier_path.mkdir(exist_ok=True)
        
        # Storage indexes
        self.objects: Dict[str, StoredObject] = {}
        self.user_objects: Dict[str, Set[str]] = {}  # user_id -> object_ids
        self.quotas: Dict[str, StorageQuota] = {}
        
        # Background tasks
        self._maintenance_task: Optional[asyncio.Task] = None
        self._running = False
        
        logger.info(f"Storage Manager initialized at {base_path}")
    
    async def start(self):
        """Start storage manager"""
        self._running = True
        self._maintenance_task = asyncio.create_task(self._maintenance_loop())
        logger.info("Storage Manager started")
    
    async def stop(self):
        """Stop storage manager"""
        self._running = False
        if self._maintenance_task:
            self._maintenance_task.cancel()
            try:
                await self._maintenance_task
            except asyncio.CancelledError:
                pass
        logger.info("Storage Manager stopped")
    
    # ============== Object Storage ==============
    
    async def store(
        self,
        data: Union[bytes, str],
        owner_id: str,
        filename: Optional[str] = None,
        tier: StorageTier = StorageTier.HOT,
        permissions: Optional[Dict[str, List[str]]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None
    ) -> Optional[StoredObject]:
        """
        Sla data op
        
        Args:
            data: Te bewaren data
            owner_id: ID van de eigenaar
            filename: Bestandsnaam
            tier: Storage tier
            permissions: Permissions per gebruiker
            metadata: Extra metadata
            tags: Tags
            
        Returns:
            StoredObject of None bij falen
        """
        # Convert to bytes
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        size = len(data)
        
        # Check quota
        if not self._check_quota(owner_id, size):
            logger.warning(f"Quota exceeded for user {owner_id}")
            return None
        
        # Generate ID
        obj_id = str(uuid4())
        content_hash = hashlib.sha256(data).hexdigest()
        
        # Determine path
        tier_config = self.TIER_CONFIG[tier]
        tier_path = self.base_path / tier_config['path']
        
        # Organize by date
        date_path = datetime.now().strftime('%Y/%m/%d')
        obj_path = tier_path / date_path / obj_id
        obj_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Compress if needed
        compressed = tier_config['compress']
        if compressed:
            data = zlib.compress(data)
        
        # Encrypt if needed (placeholder)
        encrypted = tier_config['encrypt']
        if encrypted:
            # In productie: echte encryptie
            pass
        
        # Write file
        try:
            with open(obj_path, 'wb') as f:
                f.write(data)
        except Exception as e:
            logger.error(f"Failed to write file: {e}")
            return None
        
        # Create object record
        obj = StoredObject(
            id=obj_id,
            path=str(obj_path),
            size_bytes=size,
            content_hash=content_hash,
            owner_id=owner_id,
            tier=tier,
            permissions=self._parse_permissions(permissions),
            metadata=metadata or {},
            compressed=compressed,
            encrypted=encrypted,
            tags=tags or []
        )
        
        # Store
        self.objects[obj_id] = obj
        
        if owner_id not in self.user_objects:
            self.user_objects[owner_id] = set()
        self.user_objects[owner_id].add(obj_id)
        
        # Update quota
        self._update_quota(owner_id, size, 1)
        
        logger.info(f"Stored object {obj_id} ({size} bytes) in {tier.value} tier")
        return obj
    
    async def retrieve(
        self,
        obj_id: str,
        user_id: str
    ) -> Optional[bytes]:
        """
        Haal object op
        
        Args:
            obj_id: ID van het object
            user_id: ID van de gebruiker
            
        Returns:
            Object data of None
        """
        if obj_id not in self.objects:
            return None
        
        obj = self.objects[obj_id]
        
        # Check permissions
        if not self._has_permission(obj, user_id, Permission.READ):
            logger.warning(f"User {user_id} lacks read permission for {obj_id}")
            return None
        
        # Read file
        try:
            with open(obj.path, 'rb') as f:
                data = f.read()
        except Exception as e:
            logger.error(f"Failed to read file: {e}")
            return None
        
        # Decrypt if needed
        if obj.encrypted:
            # In productie: echte decryptie
            pass
        
        # Decompress if needed
        if obj.compressed:
            data = zlib.decompress(data)
        
        # Update access stats
        obj.access_count += 1
        obj.accessed_at = datetime.now()
        
        logger.info(f"Retrieved object {obj_id}")
        return data
    
    async def delete(
        self,
        obj_id: str,
        user_id: str
    ) -> bool:
        """
        Verwijder object
        
        Args:
            obj_id: ID van het object
            user_id: ID van de gebruiker
            
        Returns:
            Success
        """
        if obj_id not in self.objects:
            return False
        
        obj = self.objects[obj_id]
        
        # Check permissions
        if not self._has_permission(obj, user_id, Permission.DELETE):
            logger.warning(f"User {user_id} lacks delete permission for {obj_id}")
            return False
        
        # Delete file
        try:
            os.remove(obj.path)
        except Exception as e:
            logger.error(f"Failed to delete file: {e}")
            return False
        
        # Update quota
        self._update_quota(obj.owner_id, -obj.size_bytes, -1)
        
        # Remove from indexes
        del self.objects[obj_id]
        
        if obj.owner_id in self.user_objects:
            self.user_objects[obj.owner_id].discard(obj_id)
        
        logger.info(f"Deleted object {obj_id}")
        return True
    
    async def update_permissions(
        self,
        obj_id: str,
        user_id: str,
        permissions: Dict[str, List[str]]
    ) -> bool:
        """
        Update object permissions
        
        Args:
            obj_id: ID van het object
            user_id: ID van de gebruiker
            permissions: Nieuwe permissions
            
        Returns:
            Success
        """
        if obj_id not in self.objects:
            return False
        
        obj = self.objects[obj_id]
        
        # Check permissions
        if not self._has_permission(obj, user_id, Permission.ADMIN):
            logger.warning(f"User {user_id} lacks admin permission for {obj_id}")
            return False
        
        obj.permissions = self._parse_permissions(permissions)
        
        logger.info(f"Updated permissions for object {obj_id}")
        return True
    
    async def move_tier(
        self,
        obj_id: str,
        new_tier: StorageTier
    ) -> bool:
        """
        Verplaats object naar andere tier
        
        Args:
            obj_id: ID van het object
            new_tier: Nieuwe tier
            
        Returns:
            Success
        """
        if obj_id not in self.objects:
            return False
        
        obj = self.objects[obj_id]
        
        if obj.tier == new_tier:
            return True
        
        # Retrieve current data
        with open(obj.path, 'rb') as f:
            data = f.read()
        
        # Decompress if needed
        if obj.compressed:
            data = zlib.decompress(data)
        
        # Determine new path
        tier_config = self.TIER_CONFIG[new_tier]
        tier_path = self.base_path / tier_config['path']
        
        date_path = obj.created_at.strftime('%Y/%m/%d')
        new_path = tier_path / date_path / obj_id
        new_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Compress if needed
        new_compressed = tier_config['compress']
        if new_compressed:
            data = zlib.compress(data)
        
        # Write to new location
        with open(new_path, 'wb') as f:
            f.write(data)
        
        # Remove old file
        try:
            os.remove(obj.path)
        except:
            pass
        
        # Update object
        obj.path = str(new_path)
        obj.tier = new_tier
        obj.compressed = new_compressed
        obj.encrypted = tier_config['encrypt']
        
        old_tier_val = obj.tier.value if hasattr(obj.tier, 'value') else str(obj.tier)
        logger.info(f"Moved object {obj_id} to {new_tier.value} tier")
        # BUG8 FIX: notify Trinity Core of tier change
        try:
            import asyncio as _aio_mv
            _aio_mv.create_task(notify_trinity_core_on_tier_change(
                obj_id, old_tier_val, new_tier.value, {"size_bytes": obj.size_bytes}
            ))
        except RuntimeError:
            pass
        return True
    
    # ============== Quota Management ==============
    
    def set_quota(
        self,
        user_id: str,
        max_bytes: int,
        max_files: int
    ):
        """Set user quota"""
        if user_id not in self.quotas:
            self.quotas[user_id] = StorageQuota(user_id=user_id)
        
        self.quotas[user_id].max_bytes = max_bytes
        self.quotas[user_id].max_files = max_files
        
        logger.info(f"Set quota for {user_id}: {max_bytes} bytes, {max_files} files")
    
    def get_quota(self, user_id: str) -> StorageQuota:
        """Get user quota"""
        if user_id not in self.quotas:
            # Calculate current usage
            used_bytes = 0
            used_files = 0
            
            if user_id in self.user_objects:
                for obj_id in self.user_objects[user_id]:
                    if obj_id in self.objects:
                        used_bytes += self.objects[obj_id].size_bytes
                        used_files += 1
            
            self.quotas[user_id] = StorageQuota(
                user_id=user_id,
                used_bytes=used_bytes,
                used_files=used_files
            )
        
        return self.quotas[user_id]
    
    def _check_quota(self, user_id: str, size_bytes: int) -> bool:
        """Check of operatie binnen quota valt"""
        quota = self.get_quota(user_id)
        return quota.can_store(size_bytes)
    
    def _update_quota(self, user_id: str, size_delta: int, files_delta: int):
        """Update quota usage"""
        quota = self.get_quota(user_id)
        quota.used_bytes += size_delta
        quota.used_files += files_delta
    
    # ============== Permission Helpers ==============
    
    def _parse_permissions(
        self,
        permissions: Optional[Dict[str, List[str]]]
    ) -> Dict[str, List[Permission]]:
        """Parse permission strings naar Permission enums"""
        result = {}
        
        if permissions:
            for user_id, perms in permissions.items():
                result[user_id] = [Permission(p) for p in perms]
        
        return result
    
    def _has_permission(
        self,
        obj: StoredObject,
        user_id: str,
        permission: Permission
    ) -> bool:
        """Check of gebruiker een permissie heeft"""
        # Owner always has all permissions
        if user_id == obj.owner_id:
            return True
        
        # Check explicit permissions
        if user_id in obj.permissions:
            if permission in obj.permissions[user_id]:
                return True
            if Permission.ADMIN in obj.permissions[user_id]:
                return True
        
        return False
    
    # ============== Maintenance ==============
    
    async def _maintenance_loop(self):
        """Periodieke maintenance"""
        while self._running:
            await asyncio.sleep(3600)  # Elke uur
            
            try:
                await self._tier_consolidation()
                await self._cleanup_orphaned()
            except Exception as e:
                logger.error(f"Maintenance error: {e}")
    
    async def _tier_consolidation(self):
        """Verplaats oude objecten naar lagere tiers"""
        now = datetime.now()
        
        for obj in list(self.objects.values()):
            age = now - obj.created_at
            current_config = self.TIER_CONFIG[obj.tier]
            
            # Check if should move to lower tier
            if age.days > current_config['max_age_days']:
                tiers = [StorageTier.HOT, StorageTier.WARM, StorageTier.COLD, StorageTier.FROZEN]
                current_idx = tiers.index(obj.tier)
                
                if current_idx < len(tiers) - 1:
                    new_tier = tiers[current_idx + 1]
                    await self.move_tier(obj.id, new_tier)
    
    async def _cleanup_orphaned(self):
        """Verwijder orphaned files"""
        for tier in StorageTier:
            tier_path = self.base_path / self.TIER_CONFIG[tier]['path']
            
            for root, dirs, files in os.walk(tier_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    
                    # Check if file is tracked
                    tracked = any(obj.path == file_path for obj in self.objects.values())
                    
                    if not tracked:
                        try:
                            os.remove(file_path)
                            logger.info(f"Removed orphaned file: {file_path}")
                        except:
                            pass
    
    # ============== Stats ==============
    
    def get_stats(self) -> Dict[str, Any]:
        """Haal storage statistieken"""
        total_size = sum(obj.size_bytes for obj in self.objects.values())
        
        tier_stats = {}
        for tier in StorageTier:
            tier_objects = [obj for obj in self.objects.values() if obj.tier == tier]
            tier_stats[tier.value] = {
                'count': len(tier_objects),
                'size_bytes': sum(obj.size_bytes for obj in tier_objects)
            }
        
        return {
            'total_objects': len(self.objects),
            'total_size_bytes': total_size,
            'total_users': len(self.user_objects),
            'tier_stats': tier_stats,
            'quota_usage': {
                user_id: {
                    'used_bytes': quota.used_bytes,
                    'max_bytes': quota.max_bytes,
                    'usage_percent': (quota.used_bytes / quota.max_bytes * 100) if quota.max_bytes > 0 else 0
                }
                for user_id, quota in self.quotas.items()
            }
        }


# Singleton instance
_storage_manager: Optional[StorageManager] = None


def get_storage_manager(base_path: str = "./storage") -> StorageManager:
    """Get or create singleton storage manager instance"""
    global _storage_manager
    if _storage_manager is None:
        _storage_manager = StorageManager(base_path)
    return _storage_manager


# ══════════════════════════════════════════════════════════════════
# UAGL KARARGAH ENTEGRASYONU — trinity_core.py ile köprü
# ══════════════════════════════════════════════════════════════════

import httpx as _httpx_storage
import json as _json_storage
import time as _time_storage

_TRINITY_CORE_URL = "http://localhost:7700"
_STORAGE_INGEST_ENABLED = True

async def notify_trinity_core_on_tier_change(obj_id: str, old_tier: str, new_tier: str, meta: dict = None):
    """
    Tier değişikliğini Trinity Core RAG'a bildirir.
    Trinity Core → FAISS index'i güncel kappa değeriyle günceller.
    """
    global _STORAGE_INGEST_ENABLED
    if not _STORAGE_INGEST_ENABLED:
        return
    # Yeni tier → kappa mapping
    tier_kappa = {'hot': 0.80, 'warm': 0.60, 'cold': 0.35, 'frozen': 0.15}
    new_kappa = tier_kappa.get(new_tier, 0.50)
    try:
        async with _httpx_storage.AsyncClient(timeout=3.0) as c:
            await c.post(f"{_TRINITY_CORE_URL}/ingest", json={
                "content": (
                    f"TIER DEĞİŞİKLİK: obj={obj_id} {old_tier}→{new_tier} | "
                    f"{_json_storage.dumps(meta or {})[:200]}"
                ),
                "source":     "trinity-storage",
                "session_id": "STORAGE-MANAGER",
                "metadata":   {"type": "tier_change", "obj_id": obj_id,
                                "old_tier": old_tier, "new_tier": new_tier, **(meta or {})},
                "kappa":      new_kappa,
            })
    except Exception:
        _STORAGE_INGEST_ENABLED = False  # core down, sessizce devre dışı

