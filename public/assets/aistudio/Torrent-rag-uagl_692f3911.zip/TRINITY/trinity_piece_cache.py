"""
UAGL_BROTHERHOOD_TEAM · TRINITY PIECE CACHE
============================

Piece-based knowledge storage for P2P distribution:
- Maps knowledge chunks to torrent-style pieces
- Bitfield tracking per info_hash
- File-based persistence under ./storage/torrent_cache/
- Content-addressable piece IDs (SHA256)

@author VEKIL-KAAN / SATEN
@version 3.0-UAGL-KARARGAH
"""

import hashlib
import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)

# Default piece size: 256 KB
DEFAULT_PIECE_SIZE = 256 * 1024


@dataclass
class TorrentMeta:
    """Metadata for a knowledge torrent"""
    info_hash: str
    chunk_id: str
    piece_ids: List[str]
    total_size: int
    piece_size: int = DEFAULT_PIECE_SIZE
    created_at: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            'info_hash': self.info_hash,
            'chunk_id': self.chunk_id,
            'piece_ids': self.piece_ids,
            'total_size': self.total_size,
            'piece_size': self.piece_size,
            'created_at': self.created_at,
            'metadata': self.metadata
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'TorrentMeta':
        return cls(**data)


class TorrentPieceCache:
    """
    Piece-based knowledge cache for P2P distribution.

    Knowledge chunks are split into pieces (like torrent pieces).
    Each piece is content-addressable via SHA256.
    Pieces are stored as files for persistence across restarts.
    """

    def __init__(self, cache_dir: str = "./storage/torrent_cache"):
        self.cache_dir = Path(cache_dir)
        self.pieces_dir = self.cache_dir / "pieces"
        self.meta_dir = self.cache_dir / "meta"

        # Create directories
        self.pieces_dir.mkdir(parents=True, exist_ok=True)
        self.meta_dir.mkdir(parents=True, exist_ok=True)

        # In-memory indexes (rebuilt from disk on init)
        self.torrents: Dict[str, TorrentMeta] = {}        # info_hash -> TorrentMeta
        self.piece_index: Dict[str, str] = {}              # piece_id -> info_hash
        self.available_pieces: Set[str] = set()            # piece_ids we have locally
        self.chunk_to_hash: Dict[str, str] = {}            # chunk_id -> info_hash

        # Rebuild indexes from disk
        self._rebuild_indexes()

        logger.info(f"TorrentPieceCache initialized at {cache_dir} "
                    f"({len(self.torrents)} torrents, {len(self.available_pieces)} pieces)")

    def _rebuild_indexes(self):
        """Rebuild in-memory indexes from persisted files"""
        # Load all torrent metadata
        for meta_file in self.meta_dir.glob("*.json"):
            try:
                with open(meta_file, 'r') as f:
                    data = json.load(f)
                meta = TorrentMeta.from_dict(data)
                self.torrents[meta.info_hash] = meta
                self.chunk_to_hash[meta.chunk_id] = meta.info_hash
                for pid in meta.piece_ids:
                    self.piece_index[pid] = meta.info_hash
            except Exception as e:
                logger.error(f"Failed to load torrent meta {meta_file}: {e}")

        # Scan available pieces
        for piece_file in self.pieces_dir.glob("*"):
            self.available_pieces.add(piece_file.name)

    def add_chunk(
        self,
        chunk_id: str,
        content: str,
        vector_bytes: Optional[bytes] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Add a knowledge chunk to the cache, splitting into pieces.

        Args:
            chunk_id: Unique ID of the knowledge chunk
            content: Text content of the chunk
            vector_bytes: Optional serialized embedding vector
            metadata: Optional metadata dict

        Returns:
            info_hash: The torrent info_hash for this chunk
        """
        # Check if already cached
        if chunk_id in self.chunk_to_hash:
            return self.chunk_to_hash[chunk_id]

        # Serialize the chunk data
        chunk_data = {
            'chunk_id': chunk_id,
            'content': content,
            'metadata': metadata or {}
        }
        payload = json.dumps(chunk_data, ensure_ascii=False).encode('utf-8')

        # Append vector bytes if present
        if vector_bytes:
            # Separator + vector
            payload = payload + b'\x00VECTOR\x00' + vector_bytes

        # Compute info_hash from full payload
        info_hash = hashlib.sha256(payload).hexdigest()

        # Split into pieces
        piece_ids = []
        offset = 0
        while offset < len(payload):
            piece_data = payload[offset:offset + DEFAULT_PIECE_SIZE]
            piece_id = hashlib.sha256(piece_data).hexdigest()
            piece_ids.append(piece_id)

            # Write piece to disk
            self._write_piece(piece_id, piece_data)
            self.available_pieces.add(piece_id)

            offset += DEFAULT_PIECE_SIZE

        # Create and persist torrent meta
        import time
        meta = TorrentMeta(
            info_hash=info_hash,
            chunk_id=chunk_id,
            piece_ids=piece_ids,
            total_size=len(payload),
            created_at=time.time(),
            metadata=metadata or {}
        )

        self.torrents[info_hash] = meta
        self.chunk_to_hash[chunk_id] = info_hash
        for pid in piece_ids:
            self.piece_index[pid] = info_hash

        # Persist metadata
        self._write_meta(info_hash, meta)

        logger.info(f"Added chunk {chunk_id} as torrent {info_hash[:16]}... "
                    f"({len(piece_ids)} pieces, {len(payload)} bytes)")

        return info_hash

    def get_piece(self, piece_id: str) -> Optional[bytes]:
        """Get a piece by its ID"""
        if piece_id not in self.available_pieces:
            return None
        return self._read_piece(piece_id)

    def has_piece(self, piece_id: str) -> bool:
        """Check if we have a piece locally"""
        return piece_id in self.available_pieces

    def store_piece(self, piece_id: str, data: bytes) -> bool:
        """
        Store a piece received from a peer.

        Args:
            piece_id: Expected piece ID (SHA256 of data)
            data: Piece data

        Returns:
            True if stored successfully and hash matches
        """
        # Verify integrity
        computed_hash = hashlib.sha256(data).hexdigest()
        if computed_hash != piece_id:
            logger.warning(f"Piece integrity check failed: expected {piece_id[:16]}..., "
                          f"got {computed_hash[:16]}...")
            return False

        self._write_piece(piece_id, data)
        self.available_pieces.add(piece_id)
        logger.debug(f"Stored piece {piece_id[:16]}... ({len(data)} bytes)")
        return True

    def get_bitfield(self, info_hash: str) -> List[bool]:
        """
        Get bitfield showing which pieces we have for a given torrent.

        Args:
            info_hash: The torrent info_hash

        Returns:
            List of bools, True = have piece, False = missing
        """
        if info_hash not in self.torrents:
            return []

        meta = self.torrents[info_hash]
        return [pid in self.available_pieces for pid in meta.piece_ids]

    def get_missing_pieces(self, info_hash: str) -> List[str]:
        """Get list of piece IDs we're missing for a torrent"""
        if info_hash not in self.torrents:
            return []

        meta = self.torrents[info_hash]
        return [pid for pid in meta.piece_ids if pid not in self.available_pieces]

    def is_complete(self, info_hash: str) -> bool:
        """Check if we have all pieces for a torrent"""
        return len(self.get_missing_pieces(info_hash)) == 0

    def reassemble_chunk(self, info_hash: str) -> Optional[Dict[str, Any]]:
        """
        Reassemble a complete chunk from its pieces.

        Returns:
            Dict with chunk_id, content, metadata — or None if incomplete
        """
        if not self.is_complete(info_hash):
            logger.warning(f"Cannot reassemble {info_hash[:16]}...: missing pieces")
            return None

        meta = self.torrents[info_hash]

        # Read and concatenate all pieces in order
        payload = b''
        for piece_id in meta.piece_ids:
            piece_data = self._read_piece(piece_id)
            if piece_data is None:
                logger.error(f"Piece {piece_id[:16]}... missing despite index")
                return None
            payload += piece_data

        # Split vector if present
        if b'\x00VECTOR\x00' in payload:
            json_part, vector_bytes = payload.split(b'\x00VECTOR\x00', 1)
        else:
            json_part = payload
            vector_bytes = None

        try:
            chunk_data = json.loads(json_part.decode('utf-8'))
            if vector_bytes:
                chunk_data['vector_bytes'] = vector_bytes
            return chunk_data
        except Exception as e:
            logger.error(f"Failed to reassemble chunk {info_hash[:16]}...: {e}")
            return None

    def get_all_info_hashes(self) -> List[str]:
        """Get all info_hashes we know about"""
        return list(self.torrents.keys())

    def get_torrent_meta(self, info_hash: str) -> Optional[TorrentMeta]:
        """Get metadata for a torrent"""
        return self.torrents.get(info_hash)

    def register_torrent(self, meta: TorrentMeta):
        """
        Register a torrent meta received from a peer (we may not have pieces yet).
        """
        if meta.info_hash not in self.torrents:
            self.torrents[meta.info_hash] = meta
            self.chunk_to_hash[meta.chunk_id] = meta.info_hash
            for pid in meta.piece_ids:
                self.piece_index[pid] = meta.info_hash
            self._write_meta(meta.info_hash, meta)
            logger.info(f"Registered torrent {meta.info_hash[:16]}... from peer")

    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_pieces = sum(len(m.piece_ids) for m in self.torrents.values())
        complete = sum(1 for h in self.torrents if self.is_complete(h))
        return {
            'total_torrents': len(self.torrents),
            'complete_torrents': complete,
            'total_pieces': total_pieces,
            'available_pieces': len(self.available_pieces),
            'cache_dir': str(self.cache_dir)
        }

    # ============== File I/O ==============

    def _write_piece(self, piece_id: str, data: bytes):
        """Write piece data to disk"""
        path = self.pieces_dir / piece_id
        with open(path, 'wb') as f:
            f.write(data)

    def _read_piece(self, piece_id: str) -> Optional[bytes]:
        """Read piece data from disk"""
        path = self.pieces_dir / piece_id
        if not path.exists():
            return None
        with open(path, 'rb') as f:
            return f.read()

    def _write_meta(self, info_hash: str, meta: TorrentMeta):
        """Write torrent metadata to disk"""
        path = self.meta_dir / f"{info_hash}.json"
        with open(path, 'w') as f:
            json.dump(meta.to_dict(), f, indent=2)

    def _read_meta(self, info_hash: str) -> Optional[TorrentMeta]:
        """Read torrent metadata from disk"""
        path = self.meta_dir / f"{info_hash}.json"
        if not path.exists():
            return None
        with open(path, 'r') as f:
            return TorrentMeta.from_dict(json.load(f))
