"""
UAGL_BROTHERHOOD_TEAM · TRINITY TRACKER SERVER
====================================

BitTorrent-style HTTP tracker for P2P peer discovery:
- POST /announce — Register/update peer for an info_hash
- GET /scrape — Get stats per info_hash
- GET /health — Tracker health check
- Background peer expiry (5 min timeout)

Runs as a FastAPI service on configurable port (default :6969).

@author VEKIL-KAAN / SATEN
@version 3.0-UAGL-KARARGAH
"""

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

logger = logging.getLogger(__name__)

# Peer expiry timeout in seconds
PEER_EXPIRY_SECONDS = 300  # 5 minutes


class AnnounceRequest(BaseModel):
    """Announce request body"""
    info_hash: str
    peer_id: str
    ip: str
    port: int
    event: str = "started"    # started, stopped, completed
    uploaded: int = 0
    downloaded: int = 0


class AnnounceResponse(BaseModel):
    """Announce response"""
    interval: int = 30        # Re-announce interval in seconds
    peers: List[Dict[str, Any]]
    complete: int = 0         # Seeders
    incomplete: int = 0       # Leechers


class ScrapeResponse(BaseModel):
    """Scrape response for a single info_hash"""
    info_hash: str
    complete: int = 0
    incomplete: int = 0
    downloaded: int = 0


@dataclass
class TrackedPeer:
    """A peer being tracked by the tracker"""
    peer_id: str
    ip: str
    port: int
    last_announce: float = field(default_factory=time.time)
    uploaded: int = 0
    downloaded: int = 0
    event: str = "started"

    def is_expired(self) -> bool:
        return (time.time() - self.last_announce) > PEER_EXPIRY_SECONDS

    def to_dict(self) -> dict:
        return {
            'peer_id': self.peer_id,
            'ip': self.ip,
            'port': self.port
        }


class TrinityTrackerServer:
    """
    Self-hosted BitTorrent-style HTTP tracker.

    Manages peer registration per info_hash and returns peer lists
    for P2P knowledge sharing.
    """

    def __init__(self, host: str = "0.0.0.0", port: int = 6969):
        self.host = host
        self.port = port

        # info_hash -> {peer_id -> TrackedPeer}
        self.swarms: Dict[str, Dict[str, TrackedPeer]] = {}

        # Track completed downloads per info_hash
        self.download_counts: Dict[str, int] = {}

        # FastAPI app
        self.app = FastAPI(title="Trinity Tracker", version="3.0")
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )
        self._setup_routes()

        # Background task
        self._cleanup_task: Optional[asyncio.Task] = None
        self._running = False
        self._server = None

        logger.info(f"TrackerServer initialized on {host}:{port}")

    def _setup_routes(self):
        """Register API routes"""

        @self.app.post("/announce", response_model=AnnounceResponse)
        async def announce(request: AnnounceRequest):
            return self._handle_announce(request)

        @self.app.get("/scrape")
        async def scrape(info_hash: Optional[str] = Query(None)):
            return self._handle_scrape(info_hash)

        @self.app.get("/health")
        async def health():
            total_peers = sum(len(peers) for peers in self.swarms.values())
            return {
                "status": "healthy",
                "swarms": len(self.swarms),
                "total_peers": total_peers,
                "uptime_info": "tracker running"
            }

        @self.app.get("/stats")
        async def stats():
            return self.get_stats()

    def _handle_announce(self, request: AnnounceRequest) -> AnnounceResponse:
        """Process an announce request"""
        info_hash = request.info_hash
        peer_id = request.peer_id

        # Initialize swarm if needed
        if info_hash not in self.swarms:
            self.swarms[info_hash] = {}
            self.download_counts[info_hash] = 0

        swarm = self.swarms[info_hash]

        if request.event == "stopped":
            # Remove peer from swarm
            swarm.pop(peer_id, None)
            logger.info(f"Peer {peer_id[:8]}... left swarm {info_hash[:16]}...")
        else:
            # Add/update peer
            swarm[peer_id] = TrackedPeer(
                peer_id=peer_id,
                ip=request.ip,
                port=request.port,
                last_announce=time.time(),
                uploaded=request.uploaded,
                downloaded=request.downloaded,
                event=request.event
            )

            if request.event == "completed":
                self.download_counts[info_hash] += 1

            logger.info(f"Peer {peer_id[:8]}... announced to swarm {info_hash[:16]}... "
                       f"(event={request.event})")

        # Build peer list (exclude the announcing peer)
        peers = [
            p.to_dict() for pid, p in swarm.items()
            if pid != peer_id and not p.is_expired()
        ]

        # Count seeders and leechers
        active_peers = [p for p in swarm.values() if not p.is_expired()]
        complete = sum(1 for p in active_peers if p.event == "completed")
        incomplete = len(active_peers) - complete

        return AnnounceResponse(
            interval=30,
            peers=peers,
            complete=complete,
            incomplete=incomplete
        )

    def _handle_scrape(self, info_hash: Optional[str] = None) -> Dict[str, Any]:
        """Process a scrape request"""
        if info_hash:
            # Scrape single hash
            swarm = self.swarms.get(info_hash, {})
            active = [p for p in swarm.values() if not p.is_expired()]
            complete = sum(1 for p in active if p.event == "completed")
            return {
                "files": {
                    info_hash: {
                        "complete": complete,
                        "incomplete": len(active) - complete,
                        "downloaded": self.download_counts.get(info_hash, 0)
                    }
                }
            }
        else:
            # Scrape all
            files = {}
            for ih, swarm in self.swarms.items():
                active = [p for p in swarm.values() if not p.is_expired()]
                complete = sum(1 for p in active if p.event == "completed")
                files[ih] = {
                    "complete": complete,
                    "incomplete": len(active) - complete,
                    "downloaded": self.download_counts.get(ih, 0)
                }
            return {"files": files}

    async def start(self):
        """Start the tracker server"""
        import uvicorn

        self._running = True
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())

        config = uvicorn.Config(
            self.app,
            host=self.host,
            port=self.port,
            log_level="warning"
        )
        self._server = uvicorn.Server(config)
        logger.info(f"Tracker server starting on http://{self.host}:{self.port}")

        # Run server (non-blocking via task) — store reference for cleanup
        self._serve_task = asyncio.create_task(self._server.serve())

        # Wait briefly for server to start
        await asyncio.sleep(0.5)
        logger.info("Tracker server is running")

    async def stop(self):
        """Stop the tracker server"""
        self._running = False
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass

        if self._server:
            self._server.should_exit = True

        # Cancel the serve task to release the port
        if hasattr(self, '_serve_task') and self._serve_task:
            self._serve_task.cancel()
            try:
                await self._serve_task
            except asyncio.CancelledError:
                pass
            self._serve_task = None

        # Brief wait for port release
        await asyncio.sleep(0.3)
        logger.info("Tracker server stopped")

    async def _cleanup_loop(self):
        """Periodically remove expired peers"""
        while self._running:
            await asyncio.sleep(60)  # Cleanup every 60 seconds
            try:
                removed = 0
                for info_hash, swarm in list(self.swarms.items()):
                    expired = [pid for pid, p in swarm.items() if p.is_expired()]
                    for pid in expired:
                        del swarm[pid]
                        removed += 1
                    # Remove empty swarms
                    if not swarm:
                        del self.swarms[info_hash]

                if removed > 0:
                    logger.info(f"Cleaned up {removed} expired peers")
            except Exception as e:
                logger.error(f"Tracker cleanup error: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """Get tracker statistics"""
        total_peers = 0
        swarm_stats = {}

        for info_hash, swarm in self.swarms.items():
            active = [p for p in swarm.values() if not p.is_expired()]
            total_peers += len(active)
            swarm_stats[info_hash[:16]] = {
                'peers': len(active),
                'complete': sum(1 for p in active if p.event == "completed"),
                'incomplete': sum(1 for p in active if p.event != "completed")
            }

        return {
            'total_swarms': len(self.swarms),
            'total_peers': total_peers,
            'swarms': swarm_stats
        }
