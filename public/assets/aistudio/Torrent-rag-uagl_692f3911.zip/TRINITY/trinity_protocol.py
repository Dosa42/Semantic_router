"""
TRINITY P2P PROTOCOL STACK
==========================

Gedistribueerde kennisdeling over P2P netwerk:
- Wire Protocol: Laag-niveau berichtenuitwisseling
- Tracker Protocol: Peer discovery en registratie
- DHT Discovery: Gedistribueerde hash table voor peer finding
- RAG Protocol: Kennisuitwisseling tussen peers

@author VEKIL-KAAN / SATEN
@version 3.0-GEMS-PRODUCTION
"""

import asyncio
import hashlib
import json
import logging
import struct
import time
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union
from collections import defaultdict
import httpx
import zlib

logger = logging.getLogger(__name__)


class P2PMessageType(Enum):
    """P2P Message Types - BitTorrent-geïnspireerd"""
    # Handshake
    HANDSHAKE = 0x00
    WELCOME = 0x01
    
    # Connection management
    KEEPALIVE = 0x02
    CHOKE = 0x03
    UNCHOKE = 0x04
    INTERESTED = 0x05
    NOT_INTERESTED = 0x06
    
    # Data exchange
    HAVE = 0x07
    BITFIELD = 0x08
    REQUEST = 0x09
    PIECE = 0x0A
    CANCEL = 0x0B
    
    # RAG-specific
    QUERY = 0x10
    QUERY_RESPONSE = 0x11
    KNOWLEDGE_OFFER = 0x12
    KNOWLEDGE_REQUEST = 0x13
    KNOWLEDGE_DATA = 0x14
    
    # Sync
    SYNC_STATUS = 0x20
    SYNC_ACK = 0x21
    NEW_HASHES = 0x22
    
    # Gem-specific
    GEM_ADVERTISE = 0x30
    GEM_REQUEST = 0x31
    GEM_TRANSFER = 0x32
    GEM_EXECUTE = 0x33
    GEM_RESULT = 0x34


@dataclass
class P2PMessage:
    """P2P Protocol Message"""
    msg_type: P2PMessageType
    payload: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    peer_id: Optional[str] = None
    
    def to_bytes(self) -> bytes:
        """Serialize message to bytes"""
        data = {
            'type': self.msg_type.value,
            'payload': self.payload,
            'timestamp': self.timestamp,
            'peer_id': self.peer_id
        }
        json_data = json.dumps(data).encode('utf-8')
        # Compress
        compressed = zlib.compress(json_data)
        # Add length prefix
        length = struct.pack('!I', len(compressed))
        return length + compressed
    
    @classmethod
    def from_bytes(cls, data: bytes) -> 'P2PMessage':
        """Deserialize message from bytes"""
        # Read length prefix
        length = struct.unpack('!I', data[:4])[0]
        compressed = data[4:4+length]
        # Decompress
        json_data = zlib.decompress(compressed)
        parsed = json.loads(json_data.decode('utf-8'))
        return cls(
            msg_type=P2PMessageType(parsed['type']),
            payload=parsed['payload'],
            timestamp=parsed['timestamp'],
            peer_id=parsed.get('peer_id')
        )


@dataclass
class PeerInfo:
    """Informatie over een P2P peer"""
    peer_id: str
    address: str
    port: int
    capabilities: List[str] = field(default_factory=list)
    last_seen: float = field(default_factory=time.time)
    knowledge_hashes: Set[str] = field(default_factory=set)
    gem_hashes: Set[str] = field(default_factory=set)
    is_choked: bool = False
    is_interested: bool = False
    reputation: float = 1.0
    
    @property
    def is_alive(self) -> bool:
        return time.time() - self.last_seen < 120  # 2 minuten timeout


class P2PWireProtocol:
    """
    P2P Wire Protocol - Laag-niveau berichtenuitwisseling
    
    Verantwoordelijk voor:
    - Verbindingen beheren
    - Berichten verzenden/ontvangen
    - Heartbeat/keepalive
    """
    
    def __init__(self, peer_id: str, listen_port: int = 0):
        self.peer_id = peer_id
        self.listen_port = listen_port
        self.peers: Dict[str, PeerInfo] = {}
        self.connections: Dict[str, asyncio.Transport] = {}
        self.message_handlers: Dict[P2PMessageType, List[Callable]] = defaultdict(list)
        self._running = False
        self._server: Optional[asyncio.Server] = None
        
    async def start(self):
        """Start de wire protocol server"""
        self._running = True
        
        # Start listening
        self._server = await asyncio.start_server(
            self._handle_connection,
            host='0.0.0.0',
            port=self.listen_port
        )
        
        addr = self._server.sockets[0].getsockname()
        self.listen_port = addr[1]
        logger.info(f"P2P Wire Protocol listening on {addr}")
        
        # Start keepalive task
        asyncio.create_task(self._keepalive_loop())
    
    async def stop(self):
        """Stop de wire protocol server"""
        self._running = False
        
        # Close all connections
        for transport in self.connections.values():
            transport.close()
        self.connections.clear()
        
        # Stop server
        if self._server:
            self._server.close()
            await self._server.wait_closed()
        
        logger.info("P2P Wire Protocol stopped")
    
    def register_handler(self, msg_type: P2PMessageType, 
                         handler: Callable[[P2PMessage, str], None]):
        """Registreer een message handler"""
        self.message_handlers[msg_type].append(handler)
    
    async def connect_to_peer(self, address: str, port: int) -> bool:
        """Maak verbinding met een peer"""
        try:
            reader, writer = await asyncio.open_connection(address, port)
            
            # Genereer peer_id
            peer_id = hashlib.sha256(f"{address}:{port}".encode()).hexdigest()[:16]
            
            # Sla peer info op
            self.peers[peer_id] = PeerInfo(
                peer_id=peer_id,
                address=address,
                port=port
            )
            self.connections[peer_id] = writer.transport
            
            # Stuur handshake
            await self._send_message(writer, P2PMessage(
                msg_type=P2PMessageType.HANDSHAKE,
                payload={'peer_id': self.peer_id, 'port': self.listen_port}
            ))
            
            # Start message handler
            asyncio.create_task(self._read_messages(peer_id, reader))
            
            logger.info(f"Connected to peer {peer_id} at {address}:{port}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect to {address}:{port}: {e}")
            return False
    
    async def broadcast(self, message: P2PMessage, 
                        exclude: Optional[List[str]] = None):
        """Broadcast bericht naar alle peers"""
        exclude = exclude or []
        
        for peer_id in self.peers:
            if peer_id not in exclude and peer_id in self.connections:
                await self.send_to_peer(peer_id, message)
    
    async def send_to_peer(self, peer_id: str, message: P2PMessage) -> bool:
        """Stuur bericht naar specifieke peer"""
        if peer_id not in self.connections:
            return False
        
        try:
            transport = self.connections[peer_id]
            writer = asyncio.StreamWriter(transport, None, None, None)
            await self._send_message(writer, message)
            return True
        except Exception as e:
            logger.error(f"Failed to send to {peer_id}: {e}")
            return False
    
    async def _handle_connection(self, reader: asyncio.StreamReader, 
                                  writer: asyncio.StreamWriter):
        """Handle nieuwe inkomende verbinding"""
        addr = writer.get_extra_info('peername')
        logger.info(f"New connection from {addr}")
        
        # Wacht op handshake
        try:
            message = await self._read_message(reader)
            if message and message.msg_type == P2PMessageType.HANDSHAKE:
                peer_id = message.payload.get('peer_id', 'unknown')
                peer_port = message.payload.get('port', addr[1])
                
                # Sla peer op
                self.peers[peer_id] = PeerInfo(
                    peer_id=peer_id,
                    address=addr[0],
                    port=peer_port
                )
                self.connections[peer_id] = writer.transport
                
                # Stuur welcome
                await self._send_message(writer, P2PMessage(
                    msg_type=P2PMessageType.WELCOME,
                    payload={'peer_id': self.peer_id, 'status': 'ok'}
                ))
                
                # Start message handler
                await self._read_messages(peer_id, reader)
            else:
                writer.close()
                
        except Exception as e:
            logger.error(f"Connection handling error: {e}")
            writer.close()
    
    async def _read_messages(self, peer_id: str, reader: asyncio.StreamReader):
        """Lees berichten van een peer"""
        while self._running:
            try:
                message = await self._read_message(reader)
                if message is None:
                    break
                
                message.peer_id = peer_id
                
                # Update last seen
                if peer_id in self.peers:
                    self.peers[peer_id].last_seen = time.time()
                
                # Dispatch naar handlers
                await self._dispatch_message(message)
                
            except asyncio.IncompleteReadError:
                break
            except Exception as e:
                logger.error(f"Error reading from {peer_id}: {e}")
                break
        
        # Cleanup
        if peer_id in self.peers:
            del self.peers[peer_id]
        if peer_id in self.connections:
            del self.connections[peer_id]
        
        logger.info(f"Peer {peer_id} disconnected")
    
    async def _read_message(self, reader: asyncio.StreamReader) -> Optional[P2PMessage]:
        """Lees een bericht van de stream"""
        try:
            # Read length prefix
            length_data = await reader.readexactly(4)
            length = struct.unpack('!I', length_data)[0]
            
            # Read message data
            data = await reader.readexactly(length)
            
            return P2PMessage.from_bytes(length_data + data)
            
        except asyncio.IncompleteReadError:
            return None
    
    async def _send_message(self, writer: asyncio.StreamWriter, message: P2PMessage):
        """Stuur een bericht over de stream"""
        data = message.to_bytes()
        writer.write(data)
        await writer.drain()
    
    async def _dispatch_message(self, message: P2PMessage):
        """Dispatch bericht naar geregistreerde handlers"""
        handlers = self.message_handlers.get(message.msg_type, [])
        for handler in handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(message, message.peer_id)
                else:
                    handler(message, message.peer_id)
            except Exception as e:
                logger.error(f"Handler error: {e}")
    
    async def _keepalive_loop(self):
        """Stuur periodieke keepalive berichten"""
        while self._running:
            await asyncio.sleep(30)  # Elke 30 seconden
            
            keepalive = P2PMessage(msg_type=P2PMessageType.KEEPALIVE)
            
            # Verwijder dode peers
            dead_peers = [
                pid for pid, info in self.peers.items() 
                if not info.is_alive
            ]
            for pid in dead_peers:
                if pid in self.connections:
                    self.connections[pid].close()
                    del self.connections[pid]
                del self.peers[pid]
                logger.info(f"Removed dead peer {pid}")
            
            # Stuur keepalive naar levende peers
            await self.broadcast(keepalive)


class TrackerProtocol:
    """
    Tracker Protocol - Peer discovery en registratie
    
    Werkt samen met centrale trackers voor:
    - Peer registratie
    - Peer discovery
    - Netwerk statistieken
    """
    
    def __init__(self, tracker_urls: List[str]):
        self.tracker_urls = tracker_urls
        self.announced_hashes: Set[str] = set()
        self.peer_cache: Dict[str, List[PeerInfo]] = {}
        
    async def announce(self, info_hash: str, peer_id: str, 
                       port: int, event: str = "started") -> List[PeerInfo]:
        """
        Announce een torrent hash naar trackers
        
        Returns:
            Lijst van peers die deze hash hebben
        """
        peers = []
        
        for tracker_url in self.tracker_urls:
            try:
                # In productie: HTTP/UDP tracker communicatie
                # Hier: simulatie
                tracker_peers = await self._query_tracker(
                    tracker_url, info_hash, peer_id, port, event
                )
                peers.extend(tracker_peers)
            except Exception as e:
                logger.error(f"Tracker announce failed for {tracker_url}: {e}")
        
        self.announced_hashes.add(info_hash)
        self.peer_cache[info_hash] = peers
        
        return peers
    
    async def _query_tracker(self, tracker_url: str, info_hash: str,
                              peer_id: str, port: int, 
                              event: str) -> List[PeerInfo]:
        """Query een specifieke tracker via HTTP"""
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    f"{tracker_url}/announce",
                    json={
                        'info_hash': info_hash,
                        'peer_id': peer_id,
                        'ip': '127.0.0.1',  # Self-report IP
                        'port': port,
                        'event': event
                    }
                )
                response.raise_for_status()
                data = response.json()
                
                peers = []
                for p in data.get('peers', []):
                    peers.append(PeerInfo(
                        peer_id=p['peer_id'],
                        address=p['ip'],
                        port=p['port']
                    ))
                
                logger.info(f"Tracker {tracker_url} returned {len(peers)} peers "
                           f"for {info_hash[:16]}...")
                return peers
        except Exception as e:
            logger.error(f"Tracker query failed for {tracker_url}: {e}")
            return []
    
    async def scrape(self, info_hash: str) -> Dict[str, Any]:
        """Scrape tracker voor statistieken"""
        stats = {
            'complete': 0,
            'incomplete': 0,
            'downloaded': 0
        }
        
        for tracker_url in self.tracker_urls:
            try:
                tracker_stats = await self._scrape_tracker(tracker_url, info_hash)
                stats['complete'] += tracker_stats.get('complete', 0)
                stats['incomplete'] += tracker_stats.get('incomplete', 0)
                stats['downloaded'] += tracker_stats.get('downloaded', 0)
            except Exception as e:
                logger.error(f"Tracker scrape failed: {e}")
        
        return stats
    
    async def _scrape_tracker(self, tracker_url: str, 
                               info_hash: str) -> Dict[str, Any]:
        """Scrape een specifieke tracker via HTTP"""
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(
                    f"{tracker_url}/scrape",
                    params={'info_hash': info_hash}
                )
                response.raise_for_status()
                data = response.json()
                files = data.get('files', {})
                if info_hash in files:
                    return files[info_hash]
                return {'complete': 0, 'incomplete': 0, 'downloaded': 0}
        except Exception as e:
            logger.error(f"Tracker scrape failed for {tracker_url}: {e}")
            return {'complete': 0, 'incomplete': 0, 'downloaded': 0}


class DHTDiscovery:
    """
    DHT Discovery - Gedistribueerde peer finding
    
    Implementeert een Kademlia-achtige DHT voor:
    - Peer discovery zonder centrale tracker
    - Gedistribueerde routing
    - Fault tolerance
    """
    
    K = 20  # Bucket size
    ALPHA = 3  # Parallel lookups
    
    def __init__(self, node_id: Optional[str] = None):
        self.node_id = node_id or hashlib.sha256(
            str(time.time()).encode()
        ).hexdigest()[:20]
        
        # Routing table: distance -> list of nodes
        self.routing_table: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
        self.storage: Dict[str, Any] = {}  # DHT storage
        
    def distance(self, node_id1: str, node_id2: str) -> int:
        """Bereken XOR distance tussen twee node IDs"""
        id1 = int(node_id1, 16)
        id2 = int(node_id2, 16)
        return id1 ^ id2
    
    def add_node(self, node_id: str, address: str, port: int):
        """Voeg node toe aan routing table"""
        dist = self.distance(self.node_id, node_id)
        bucket_index = dist.bit_length()
        
        bucket = self.routing_table[bucket_index]
        node_info = {'id': node_id, 'address': address, 'port': port}
        
        # Check if already in bucket
        for i, node in enumerate(bucket):
            if node['id'] == node_id:
                bucket[i] = node_info  # Update
                return
        
        # Add to bucket if not full
        if len(bucket) < self.K:
            bucket.append(node_info)
        else:
            # Bucket full - evict oldest node (simplified Kademlia eviction)
            # In full Kademlia: ping oldest, replace if unresponsive
            # Here: replace oldest directly (optimistic eviction)
            oldest = bucket[0]
            bucket[0] = node_info
            logger.debug(f"Evicted node {oldest['id'][:8]}... from bucket {bucket_index}, "
                        f"replaced with {node_id[:8]}...")
    
    def find_closest_nodes(self, target_id: str, k: int = 20) -> List[Dict[str, Any]]:
        """Vind k dichtste nodes bij target"""
        all_nodes = []
        for bucket in self.routing_table.values():
            all_nodes.extend(bucket)
        
        # Sort by distance to target
        all_nodes.sort(key=lambda n: self.distance(target_id, n['id']))
        
        return all_nodes[:k]
    
    async def iterative_find_node(self, target_id: str) -> List[Dict[str, Any]]:
        """Iteratief zoeken naar nodes - Kademlia algoritme"""
        closest = self.find_closest_nodes(target_id, self.K)
        queried = set()
        
        while True:
            # Select ALPHA nodes to query
            to_query = [n for n in closest if n['id'] not in queried][:self.ALPHA]
            
            if not to_query:
                break
            
            # Query nodes in parallel
            tasks = [self._query_node(node, target_id) for node in to_query]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Process results
            new_nodes = []
            for result in results:
                if isinstance(result, list):
                    new_nodes.extend(result)
            
            # Update closest
            queried.update(n['id'] for n in to_query)
            all_candidates = closest + new_nodes
            all_candidates.sort(key=lambda n: self.distance(target_id, n['id']))
            closest = all_candidates[:self.K]
            
            # Check if we found the target
            if any(n['id'] == target_id for n in closest):
                break
        
        return closest
    
    async def _query_node(self, node: Dict[str, Any], 
                          target_id: str) -> List[Dict[str, Any]]:
        """Query een node voor dichtste nodes via TCP"""
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(node['address'], node['port']),
                timeout=5.0
            )
            
            # Send FIND_NODE request
            find_msg = P2PMessage(
                msg_type=P2PMessageType.QUERY,
                payload={
                    'type': 'find_node',
                    'target_id': target_id,
                    'sender_id': self.node_id
                }
            )
            data = find_msg.to_bytes()
            writer.write(len(data).to_bytes(4, 'big') + data)
            await writer.drain()
            
            # Read response
            length_bytes = await asyncio.wait_for(reader.read(4), timeout=5.0)
            if len(length_bytes) < 4:
                return []
            length = int.from_bytes(length_bytes, 'big')
            response_data = await asyncio.wait_for(reader.read(length), timeout=5.0)
            response = P2PMessage.from_bytes(response_data)
            
            writer.close()
            
            # Add responding node to our routing table
            self.add_node(node['id'], node['address'], node['port'])
            
            return response.payload.get('nodes', [])
        except Exception as e:
            logger.debug(f"DHT query to {node['id'][:8]}... failed: {e}")
            return []
    
    def store(self, key: str, value: Any):
        """Sla waarde op in DHT"""
        self.storage[key] = value
    
    def get(self, key: str) -> Optional[Any]:
        """Haal waarde op uit DHT"""
        return self.storage.get(key)


class RAGProtocol:
    """
    RAG Protocol - Kennisuitwisseling tussen peers
    
    Extensie op P2P Wire Protocol voor:
    - Query forwarding
    - Knowledge sharing
    - Result aggregation
    """
    
    def __init__(self, wire_protocol: P2PWireProtocol, rag_server=None, torrent_cache=None):
        self.wire = wire_protocol
        self.rag_server = rag_server           # TrinityRAGServer reference
        self.torrent_cache = torrent_cache       # TorrentPieceCache reference
        self.pending_queries: Dict[str, asyncio.Future] = {}
        self.query_results: Dict[str, List[Dict]] = {}  # Accumulate multi-peer results
        self.knowledge_cache: Dict[str, Any] = {}
        
        # Registreer handlers
        self._register_handlers()
    
    def _register_handlers(self):
        """Registreer RAG message handlers"""
        self.wire.register_handler(P2PMessageType.QUERY, self._handle_query)
        self.wire.register_handler(P2PMessageType.QUERY_RESPONSE, self._handle_query_response)
        self.wire.register_handler(P2PMessageType.KNOWLEDGE_OFFER, self._handle_knowledge_offer)
        self.wire.register_handler(P2PMessageType.KNOWLEDGE_REQUEST, self._handle_knowledge_request)
        self.wire.register_handler(P2PMessageType.KNOWLEDGE_DATA, self._handle_knowledge_data)
    
    async def forward_query(self, query_id: str, query_text: str,
                          target_peers: List[str]) -> List[Dict[str, Any]]:
        """
        Forward een query naar andere peers
        
        Returns:
            Geaggregeerde resultaten van alle peers
        """
        message = P2PMessage(
            msg_type=P2PMessageType.QUERY,
            payload={
                'query_id': query_id,
                'query': query_text,
                'timestamp': time.time()
            }
        )
        
        # Create future for responses
        future = asyncio.Future()
        self.pending_queries[query_id] = future
        
        # Send to peers
        for peer_id in target_peers:
            await self.wire.send_to_peer(peer_id, message)
        
        # Wait for responses (with timeout)
        try:
            results = await asyncio.wait_for(future, timeout=10.0)
            return results
        except asyncio.TimeoutError:
            logger.warning(f"Query {query_id} timed out")
            return []
        finally:
            if query_id in self.pending_queries:
                del self.pending_queries[query_id]
    
    async def _handle_query(self, message: P2PMessage, peer_id: str):
        """Handle inkomende query — search local RAG and return results"""
        query_id = message.payload.get('query_id')
        query_text = message.payload.get('query')
        
        logger.info(f"Received query from {peer_id[:8]}...: {query_text}")
        
        # Query local RAG server if available
        results = []
        if self.rag_server:
            try:
                rag_results = await self.rag_server.query(
                    query_text, 
                    top_k=5
                )
                results = [
                    {
                        'chunk_id': r.id,
                        'content': r.content[:500],  # Limit content size for transfer
                        'score': float(r.mvs_score) if hasattr(r, 'mvs_score') else 0.0,
                        'source': r.source,
                        'peer_id': self.wire.peer_id
                    }
                    for r in rag_results
                ]
                logger.info(f"Local RAG returned {len(results)} results for query {query_id}")
            except Exception as e:
                logger.error(f"Local RAG query failed: {e}")
        
        response = P2PMessage(
            msg_type=P2PMessageType.QUERY_RESPONSE,
            payload={
                'query_id': query_id,
                'results': results,
                'peer_id': self.wire.peer_id
            }
        )
        
        await self.wire.send_to_peer(peer_id, response)
    
    async def _handle_query_response(self, message: P2PMessage, peer_id: str):
        """Handle query response — accumulate results from multiple peers"""
        query_id = message.payload.get('query_id')
        results = message.payload.get('results', [])
        resp_peer = message.payload.get('peer_id', peer_id)
        
        logger.info(f"Received {len(results)} results from {resp_peer[:8]}... "
                   f"for query {query_id}")
        
        # Accumulate results
        if query_id not in self.query_results:
            self.query_results[query_id] = []
        self.query_results[query_id].extend(results)
        
        # Resolve the future with accumulated results
        if query_id in self.pending_queries:
            future = self.pending_queries[query_id]
            if not future.done():
                future.set_result(self.query_results[query_id])
    
    async def _handle_knowledge_offer(self, message: P2PMessage, peer_id: str):
        """Handle knowledge offer — check if we need pieces and request them"""
        info_hash = message.payload.get('info_hash') or message.payload.get('hash')
        torrent_meta_dict = message.payload.get('torrent_meta')
        
        if not info_hash:
            return
        
        # Register the torrent meta if we don't have it
        if self.torrent_cache and torrent_meta_dict:
            from p2p.torrent_cache import TorrentMeta
            meta = TorrentMeta.from_dict(torrent_meta_dict)
            self.torrent_cache.register_torrent(meta)
        
        # Check which pieces we're missing
        if self.torrent_cache:
            missing = self.torrent_cache.get_missing_pieces(info_hash)
            for piece_id in missing:
                request = P2PMessage(
                    msg_type=P2PMessageType.KNOWLEDGE_REQUEST,
                    payload={
                        'info_hash': info_hash,
                        'piece_id': piece_id
                    }
                )
                await self.wire.send_to_peer(peer_id, request)
            
            if missing:
                logger.info(f"Requested {len(missing)} pieces for "
                           f"{info_hash[:16]}... from {peer_id[:8]}...")
        else:
            # Fallback: request entire knowledge blob
            if info_hash not in self.knowledge_cache:
                request = P2PMessage(
                    msg_type=P2PMessageType.KNOWLEDGE_REQUEST,
                    payload={'hash': info_hash}
                )
                await self.wire.send_to_peer(peer_id, request)
    
    async def _handle_knowledge_request(self, message: P2PMessage, peer_id: str):
        """Handle knowledge request — send requested piece data"""
        piece_id = message.payload.get('piece_id')
        info_hash = message.payload.get('info_hash') or message.payload.get('hash')
        
        # Try piece-based transfer first
        if piece_id and self.torrent_cache:
            piece_data = self.torrent_cache.get_piece(piece_id)
            if piece_data:
                data_msg = P2PMessage(
                    msg_type=P2PMessageType.KNOWLEDGE_DATA,
                    payload={
                        'info_hash': info_hash,
                        'piece_id': piece_id,
                        'data': piece_data.hex()
                    }
                )
                await self.wire.send_to_peer(peer_id, data_msg)
                logger.debug(f"Sent piece {piece_id[:16]}... to {peer_id[:8]}...")
                return
        
        # Fallback: send from knowledge_cache
        knowledge_hash = info_hash or message.payload.get('hash')
        if knowledge_hash and knowledge_hash in self.knowledge_cache:
            data_msg = P2PMessage(
                msg_type=P2PMessageType.KNOWLEDGE_DATA,
                payload={
                    'hash': knowledge_hash,
                    'data': self.knowledge_cache[knowledge_hash]
                }
            )
            await self.wire.send_to_peer(peer_id, data_msg)
        else:
            logger.warning(f"Requested knowledge not found: "
                          f"piece={piece_id[:16] if piece_id else 'N/A'}... "
                          f"hash={knowledge_hash[:16] if knowledge_hash else 'N/A'}...")
    
    async def _handle_knowledge_data(self, message: P2PMessage, peer_id: str):
        """Handle ontvangen knowledge data — store piece in cache"""
        piece_id = message.payload.get('piece_id')
        info_hash = message.payload.get('info_hash')
        data_hex = message.payload.get('data', '')
        
        if piece_id and self.torrent_cache:
            # Piece-based storage
            try:
                piece_data = bytes.fromhex(data_hex)
                stored = self.torrent_cache.store_piece(piece_id, piece_data)
                if stored:
                    logger.info(f"Stored piece {piece_id[:16]}... from {peer_id[:8]}...")
                    
                    # Check if torrent is now complete
                    if info_hash and self.torrent_cache.is_complete(info_hash):
                        chunk_data = self.torrent_cache.reassemble_chunk(info_hash)
                        if chunk_data:
                            logger.info(f"Torrent {info_hash[:16]}... complete! "
                                       f"Chunk: {chunk_data.get('chunk_id', 'unknown')}")
                            # Ingest into local RAG if available
                            if self.rag_server and 'content' in chunk_data:
                                try:
                                    await self.rag_server.ingest(
                                        content=chunk_data['content'],
                                        metadata=chunk_data.get('metadata', {}),
                                        source=f"p2p:{peer_id[:8]}"
                                    )
                                    logger.info(f"Ingested P2P knowledge into local RAG")
                                except Exception as e:
                                    logger.error(f"Failed to ingest P2P knowledge: {e}")
            except Exception as e:
                logger.error(f"Failed to process piece data: {e}")
        else:
            # Fallback: store in knowledge_cache
            knowledge_hash = message.payload.get('hash', info_hash)
            data = message.payload.get('data')
            if knowledge_hash:
                self.knowledge_cache[knowledge_hash] = data
                logger.info(f"Received knowledge {knowledge_hash[:16]}... from {peer_id[:8]}...")


# Factory functie voor complete P2P stack
def create_p2p_stack(
    peer_id: str, 
    listen_port: int,
    tracker_urls: List[str],
    rag_server=None,
    torrent_cache=None
) -> Tuple[P2PWireProtocol, RAGProtocol, TrackerProtocol, DHTDiscovery]:
    """Creëer complete P2P protocol stack"""
    wire = P2PWireProtocol(peer_id, listen_port)
    rag = RAGProtocol(wire, rag_server=rag_server, torrent_cache=torrent_cache)
    tracker = TrackerProtocol(tracker_urls)
    dht = DHTDiscovery(peer_id)
    
    return wire, rag, tracker, dht
