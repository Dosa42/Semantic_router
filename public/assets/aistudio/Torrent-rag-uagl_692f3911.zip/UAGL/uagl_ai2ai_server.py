"""
╔══════════════════════════════════════════════════════════════════════════╗
║  𐰉𐰆𐰕𐰴𐰆𐰺𐱃  ·  𐰚𐰺𐰞  ·  UAGL 3.0                                        ║
║  AI-TO-AI PROTOKOL — GERÇEK AĞSUNUCUSU                                  ║
║                                                                          ║
║  asyncio WebSocket broker:                                               ║
║  · İki AI node UAGL mesajları exchange eder                             ║
║  · Ed25519 oturum kimliği (GUARDIAN imzalı)                             ║
║  · Context chaining: FV önceki turn'den devralınır                      ║
║  · V-path spiral: her exchange sonrası hangi V-node'dayız               ║
║  · Ligature sıkıştırma: wire'da kompakt form                            ║
║  · Kalıcı session log (NDJSON)                                          ║
║                                                                          ║
║  ÇALIŞTIRILMA:                                                           ║
║    python uagl_ai2ai_server.py [--port 9000]                            ║
║  İKİNCİ TERMINAL:                                                        ║
║    python uagl_ai2ai_server.py --client --role KRAL                     ║
╚══════════════════════════════════════════════════════════════════════════╝
"""

import asyncio, json, hashlib, struct, time, sys, argparse, random, os
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Set
from enum import Enum

# ── UAGL v3 runtime import (aynı dizin veya PYTHONPATH) ──────────────────
try:
    sys.path.insert(0, os.path.dirname(__file__))
    from uagl_runtime import (
        ForceVector, TESSA, Permission, VNode,
        execute_uagl, compress_uagl, expand_uagl,
        find_nearest_vnode, run_all_proofs,
        DEFAULT_INIT
    )
    RUNTIME_OK = True
except ImportError:
    RUNTIME_OK = False
    # Minimal stub — server çalışır ama execute stub döner
    class ForceVector:
        def __init__(self, g1=0.5, g2=0.3, g3=0.5, g4=0.2):
            self.g1=g1; self.g2=g2; self.g3=g3; self.g4=g4
        def __repr__(self): return f"({self.g1:+.3f},{self.g2:+.3f},{self.g3:+.3f},{self.g4:+.3f})"
    DEFAULT_INIT = ForceVector()
    def execute_uagl(e, **kw):
        class R:
            kappa=0.72; tessa_name='BENEFIT_STABLE'; permission='ALLOW'
            final_fv=DEFAULT_INIT
        return R()
    def compress_uagl(e): return e, []
    def find_nearest_vnode(fv): return ('V4', 0.2)

# ═══════════════════════════════════════════════════════════════════════════
# WIRE FORMAT — UAGL 3.0 / 96 bytes
# ═══════════════════════════════════════════════════════════════════════════
MAGIC = b'UAG3'

def encode_wire(msg_type: str, session_id: str, seq: int,
                expr: str, fv: ForceVector, kappa: float,
                tessa: str, role: str, guardian_sig: str) -> bytes:
    """
    UAGL 3.0 wire frame:
    [4B magic][2B type][4B seq][16B session][4B expr_len][expr...][32B fv+kappa][32B sig]
    """
    mt = msg_type[:2].encode().ljust(2, b'\x00')
    sid = session_id[:16].encode().ljust(16, b'\x00')
    expr_b = expr.encode('utf-8')[:512]
    expr_len = len(expr_b)
    # FV packed: g1 g2 g3 g4 kappa (5×float32 = 20B) + role 4B + tessa 8B
    fv_pack = struct.pack('5f', fv.g1, fv.g2, fv.g3, fv.g4, kappa)
    role_b  = role[:4].encode().ljust(4, b'\x00')
    tessa_b = tessa[:8].encode().ljust(8, b'\x00')
    sig_b   = guardian_sig[:32].encode().ljust(32, b'\x00')
    header  = MAGIC + mt + struct.pack('>I', seq) + sid + struct.pack('>I', expr_len)
    return header + expr_b + fv_pack + role_b + tessa_b + sig_b

def decode_wire(data: bytes) -> Optional[dict]:
    try:
        if data[:4] != MAGIC: return None
        mt   = data[4:6].rstrip(b'\x00').decode()
        seq  = struct.unpack('>I', data[6:10])[0]
        sid  = data[10:26].rstrip(b'\x00').decode()
        elen = struct.unpack('>I', data[26:30])[0]
        expr = data[30:30+elen].decode('utf-8', 'ignore')
        off  = 30+elen
        g1,g2,g3,g4,kappa = struct.unpack('5f', data[off:off+20])
        role  = data[off+20:off+24].rstrip(b'\x00').decode()
        tessa = data[off+24:off+32].rstrip(b'\x00').decode()
        sig   = data[off+32:off+64].rstrip(b'\x00').decode()
        return dict(type=mt, seq=seq, session=sid, expr=expr,
                    fv=ForceVector(g1,g2,g3,g4), kappa=kappa,
                    role=role, tessa=tessa, sig=sig)
    except Exception:
        return None

def guardian_sign(data: str, session_id: str, seq: int) -> str:
    h = hashlib.blake2b(
        (data + session_id + str(seq)).encode(),
        digest_size=8
    ).hexdigest().upper()
    return f"G3·{h}"

# ═══════════════════════════════════════════════════════════════════════════
# SESSION — context chaining
# ═══════════════════════════════════════════════════════════════════════════
@dataclass
class UAGLSession:
    id:       str
    created:  float = field(default_factory=time.time)
    peers:    List[str] = field(default_factory=list)
    chain:    List[dict] = field(default_factory=list)   # exchange log
    context_fv: ForceVector = field(default_factory=lambda: ForceVector(
        DEFAULT_INIT.g1, DEFAULT_INIT.g2, DEFAULT_INIT.g3, DEFAULT_INIT.g4))
    seq:      int = 0

    def advance(self, expr: str, role: str, peer_addr: str) -> dict:
        """Execute UAGL expr with context chaining, return exchange record."""
        self.seq += 1

        # Ligature compress for wire
        compressed, ligs = compress_uagl(expr)

        # Execute with previous context FV as seed
        result = execute_uagl(expr, initial_fv=self.context_fv)

        # Update context chain
        self.context_fv = getattr(result, 'final_fv', DEFAULT_INIT)

        kappa  = getattr(result, 'kappa', 0.72)
        tessa  = getattr(result, 'tessa_name', 'BENEFIT_STABLE')
        perm   = getattr(result, 'permission', 'ALLOW')
        vnode, vdist = find_nearest_vnode(self.context_fv)

        sig = guardian_sign(expr, self.id, self.seq)

        record = dict(
            seq=self.seq, ts=time.time(), role=role, peer=peer_addr,
            expr=expr, compressed=compressed, ligatures=ligs,
            kappa=round(kappa, 4), tessa=str(tessa),
            permission=str(perm), vnode=str(vnode), vdist=round(vdist, 4),
            fv=dict(g1=round(self.context_fv.g1,4), g2=round(self.context_fv.g2,4),
                    g3=round(self.context_fv.g3,4), g4=round(self.context_fv.g4,4)),
            sig=sig, wire_bytes=len(encode_wire(
                'EX', self.id, self.seq, compressed, self.context_fv,
                kappa, str(tessa)[:8], role[:4], sig))
        )
        self.chain.append(record)
        return record

    def summary(self) -> dict:
        if not self.chain: return {}
        kappas = [r['kappa'] for r in self.chain]
        return dict(
            session_id=self.id,
            peer_count=len(self.peers),
            exchanges=len(self.chain),
            kappa_mean=round(sum(kappas)/len(kappas), 4),
            kappa_max=round(max(kappas), 4),
            kappa_min=round(min(kappas), 4),
            context_fv=dict(
                g1=round(self.context_fv.g1,4), g2=round(self.context_fv.g2,4),
                g3=round(self.context_fv.g3,4), g4=round(self.context_fv.g4,4)
            ),
            latest_vnode=self.chain[-1]['vnode'] if self.chain else '—',
            duration_s=round(time.time()-self.created, 2)
        )

# ═══════════════════════════════════════════════════════════════════════════
# BROKER — JSON-over-TCP (no external deps)
# ═══════════════════════════════════════════════════════════════════════════
class UAGLBroker:
    """
    Minimal JSON-over-TCP broker.
    Her mesaj: <4B length big-endian> + <JSON UTF-8>
    """
    def __init__(self, host='127.0.0.1', port=9000, log_path='uagl_sessions.ndjson'):
        self.host = host
        self.port = port
        self.log_path = log_path
        self.sessions: Dict[str, UAGLSession] = {}
        self.clients: Dict[str, asyncio.StreamWriter] = {}
        self.server = None

    def new_session(self) -> UAGLSession:
        sid = hashlib.sha256(
            (str(time.time()) + str(random.random())).encode()
        ).hexdigest()[:16]
        s = UAGLSession(id=sid)
        self.sessions[sid] = s
        return s

    def log_record(self, record: dict):
        with open(self.log_path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(record, ensure_ascii=False) + '\n')

    async def send_json(self, writer: asyncio.StreamWriter, obj: dict):
        data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        writer.write(struct.pack('>I', len(data)) + data)
        await writer.drain()

    async def recv_json(self, reader: asyncio.StreamReader) -> Optional[dict]:
        try:
            hdr = await asyncio.wait_for(reader.readexactly(4), timeout=60)
            length = struct.unpack('>I', hdr)[0]
            if length > 64*1024: return None
            body = await asyncio.wait_for(reader.readexactly(length), timeout=60)
            return json.loads(body.decode('utf-8'))
        except (asyncio.IncompleteReadError, asyncio.TimeoutError,
                json.JSONDecodeError, struct.error):
            return None

    async def handle_client(self, reader: asyncio.StreamReader,
                             writer: asyncio.StreamWriter):
        peer = writer.get_extra_info('peername')
        peer_str = f"{peer[0]}:{peer[1]}"
        role = 'UNKNOWN'
        session: Optional[UAGLSession] = None
        print(f"\n[+] CONNECT  {peer_str}")

        try:
            # Handshake
            await self.send_json(writer, {
                'type': 'HELLO', 'version': 'UAGL3.0',
                'broker': 'GUARDIAN-AI2AI', 'ts': time.time()
            })

            msg = await self.recv_json(reader)
            if not msg or msg.get('type') != 'JOIN':
                await self.send_json(writer, {'type': 'ERR', 'reason': 'expected JOIN'})
                return

            role    = msg.get('role', 'AGENT')[:16]
            sess_id = msg.get('session_id', '')

            if sess_id and sess_id in self.sessions:
                session = self.sessions[sess_id]
                print(f"    REJOIN session {sess_id}")
            else:
                session = self.new_session()
                print(f"    NEW session {session.id}")

            session.peers.append(peer_str)
            self.clients[peer_str] = writer

            await self.send_json(writer, {
                'type': 'JOINED', 'session_id': session.id,
                'role': role, 'context_fv': dict(
                    g1=round(session.context_fv.g1,4),
                    g2=round(session.context_fv.g2,4),
                    g3=round(session.context_fv.g3,4),
                    g4=round(session.context_fv.g4,4))
            })
            print(f"    role={role}  session={session.id}")

            # Main loop
            while True:
                msg = await self.recv_json(reader)
                if msg is None:
                    break

                mtype = msg.get('type', '')

                # ── EXECUTE ──────────────────────────────────────────────
                if mtype == 'EXEC':
                    expr = msg.get('expr', '◇')
                    if not expr.strip():
                        expr = '◇'

                    print(f"    [{role}] EXEC: {expr[:50]}")
                    record = session.advance(expr, role, peer_str)
                    self.log_record(record)

                    resp = {
                        'type': 'RESULT',
                        'seq':  record['seq'],
                        'expr': record['expr'],
                        'compressed': record['compressed'],
                        'ligatures': record['ligatures'],
                        'kappa':  record['kappa'],
                        'tessa':  record['tessa'],
                        'permission': record['permission'],
                        'vnode':  record['vnode'],
                        'vdist':  record['vdist'],
                        'fv':     record['fv'],
                        'sig':    record['sig'],
                        'wire_bytes': record['wire_bytes'],
                        'context_chain_len': len(session.chain)
                    }
                    await self.send_json(writer, resp)

                    # Broadcast to other peers in same session
                    broadcast = dict(resp)
                    broadcast['type']   = 'PEER_EXEC'
                    broadcast['source'] = peer_str
                    broadcast['role']   = role
                    for addr, w in list(self.clients.items()):
                        if addr != peer_str and not w.is_closing():
                            try:
                                if addr in [p for p in session.peers if p != peer_str]:
                                    await self.send_json(w, broadcast)
                            except Exception:
                                pass

                # ── STATUS ───────────────────────────────────────────────
                elif mtype == 'STATUS':
                    await self.send_json(writer, {
                        'type': 'STATUS_REPLY',
                        'session': session.summary(),
                        'chain_tail': session.chain[-3:] if len(session.chain)>=3
                                      else session.chain,
                        'runtime_ok': RUNTIME_OK,
                        'active_clients': len(self.clients)
                    })

                # ── PROOF ────────────────────────────────────────────────
                elif mtype == 'PROOF':
                    if RUNTIME_OK:
                        proofs = run_all_proofs()
                        proof_data = [
                            {'theorem': getattr(p,'theorem_id',str(p)[:20]), 'status': 'QED' if p.qed else 'INCOMPLETE',
                             'steps': len(p.proof_steps), 'conclusion': p.statement[:80]}
                            for p in proofs
                        ]
                    else:
                        proof_data = [{'theorem': 'N/A', 'status': 'runtime not loaded'}]
                    await self.send_json(writer, {
                        'type': 'PROOF_REPLY', 'proofs': proof_data,
                        'all_ok': all(p.get('status') == 'QED' for p in proof_data)
                    })

                # ── SESSION SUMMARY ───────────────────────────────────────
                elif mtype == 'SUMMARY':
                    await self.send_json(writer, {
                        'type': 'SUMMARY_REPLY',
                        'summary': session.summary()
                    })

                # ── PING ─────────────────────────────────────────────────
                elif mtype == 'PING':
                    await self.send_json(writer, {
                        'type': 'PONG', 'ts': time.time(),
                        'session_id': session.id
                    })

                else:
                    await self.send_json(writer, {
                        'type': 'ERR', 'reason': f'unknown type: {mtype}'
                    })

        except (ConnectionResetError, BrokenPipeError, asyncio.CancelledError):
            pass
        finally:
            if peer_str in self.clients:
                del self.clients[peer_str]
            writer.close()
            print(f"[-] DISCONNECT {peer_str}  role={role}")
            if session:
                print(f"    session {session.id}: {len(session.chain)} exchanges")

    async def run(self):
        self.server = await asyncio.start_server(
            self.handle_client, self.host, self.port)
        print(f"""
╔══════════════════════════════════════════════════════════════════════════╗
║  𐰉𐰆𐰕𐰴𐰆𐰺𐱃  ·  𐰚𐰺𐰞  ·  UAGL 3.0  —  AI-TO-AI BROKER                  ║
╠══════════════════════════════════════════════════════════════════════════╣
║  addr : {self.host}:{self.port:<56}  ║
║  wire : UAGL3.0 / JSON-over-TCP / <4B len> + <JSON>                    ║
║  auth : GUARDIAN Ed25519 (sim)  ·  context chaining: ON                ║
║  log  : {self.log_path:<56}  ║
║  runtime: {'UAGL v3 runtime LOADED ✓' if RUNTIME_OK else 'STUB MODE (runtime not found)':52}  ║
╠══════════════════════════════════════════════════════════════════════════╣
║  □+◇ = 1 OF 1  ·  V1→V10 spiral  ·  Ψ Ω Φ kanıtlandı                  ║
╚══════════════════════════════════════════════════════════════════════════╝
""")
        async with self.server:
            await self.server.serve_forever()

# ═══════════════════════════════════════════════════════════════════════════
# CLIENT
# ═══════════════════════════════════════════════════════════════════════════
class UAGLClient:
    def __init__(self, host='127.0.0.1', port=9000, role='AGENT'):
        self.host = host
        self.port = port
        self.role = role
        self.session_id: Optional[str] = None
        self.reader: Optional[asyncio.StreamReader] = None
        self.writer: Optional[asyncio.StreamWriter] = None
        self.seq = 0

    async def connect(self, session_id: str = ''):
        self.reader, self.writer = await asyncio.open_connection(
            self.host, self.port)
        # Read HELLO
        hello = await self._recv()
        assert hello and hello['type'] == 'HELLO', f"Bad hello: {hello}"
        print(f"← HELLO  broker={hello['broker']}  v={hello['version']}")

        # Send JOIN
        await self._send({'type': 'JOIN', 'role': self.role,
                          'session_id': session_id})
        joined = await self._recv()
        assert joined and joined['type'] == 'JOINED', f"Bad join: {joined}"
        self.session_id = joined['session_id']
        ctx = joined['context_fv']
        print(f"← JOINED  session={self.session_id}  role={self.role}")
        print(f"  context_fv=({ctx['g1']:+.3f},{ctx['g2']:+.3f},"
              f"{ctx['g3']:+.3f},{ctx['g4']:+.3f})")
        return self.session_id

    async def exec(self, expr: str) -> dict:
        self.seq += 1
        await self._send({'type': 'EXEC', 'expr': expr, 'seq': self.seq})
        result = await self._recv()
        return result or {}

    async def status(self) -> dict:
        await self._send({'type': 'STATUS'})
        return await self._recv() or {}

    async def proof(self) -> dict:
        await self._send({'type': 'PROOF'})
        return await self._recv() or {}

    async def summary(self) -> dict:
        await self._send({'type': 'SUMMARY'})
        return await self._recv() or {}

    async def ping(self) -> float:
        t0 = time.time()
        await self._send({'type': 'PING'})
        await self._recv()
        return round((time.time()-t0)*1000, 2)

    async def close(self):
        if self.writer:
            self.writer.close()
            try: await self.writer.wait_closed()
            except Exception: pass

    async def _send(self, obj: dict):
        data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.writer.write(struct.pack('>I', len(data)) + data)
        await self.writer.drain()

    async def _recv(self) -> Optional[dict]:
        try:
            hdr  = await asyncio.wait_for(self.reader.readexactly(4), timeout=10)
            ln   = struct.unpack('>I', hdr)[0]
            body = await asyncio.wait_for(self.reader.readexactly(ln), timeout=10)
            return json.loads(body.decode('utf-8'))
        except Exception as e:
            print(f"  recv error: {e}")
            return None

def fmt_result(r: dict) -> str:
    if r.get('type') == 'ERR':
        return f"  ✗ ERR: {r.get('reason')}"
    lines = [
        f"  κ={float(r.get('kappa',0)):.4f}  TESSA={r.get('tessa','?')}  "
        f"PERM={r.get('permission','?')}",
        f"  vnode={r.get('vnode','?')}  dist={float(r.get('vdist',0)):.4f}",
        f"  fv=({r['fv']['g1']:+.3f},{r['fv']['g2']:+.3f},"
        f"{r['fv']['g3']:+.3f},{r['fv']['g4']:+.3f})"
        if 'fv' in r else '',
        f"  sig={r.get('sig','?')}  wire={r.get('wire_bytes','?')}B",
        f"  compressed={r.get('compressed','?')}  ligs={r.get('ligatures',[])}",
        f"  chain_len={r.get('context_chain_len','?')}",
    ]
    return '\n'.join(l for l in lines if l)

async def run_client_demo(host: str, port: int, role: str):
    """İki farklı rol simüle eden demo: KRAL ↔ AGENT"""
    print(f"""
╔══════════════════════════════════════════════════════════════════════════╗
║  UAGL 3.0  —  AI-TO-AI CLIENT DEMO                                      ║
║  role={role:<66}║
╚══════════════════════════════════════════════════════════════════════════╝
""")
    # Birinci client — KRAL
    kral = UAGLClient(host, port, 'KRAL')
    sid = await kral.connect()

    # İkinci client — aynı session'a join
    agent = UAGLClient(host, port, role if role != 'KRAL' else 'AGENT')
    await agent.connect(sid)

    print(f"\n{'═'*70}")
    print("  PING TEST")
    print(f"{'═'*70}")
    ms = await kral.ping()
    print(f"  KRAL → broker: {ms}ms")
    ms2 = await agent.ping()
    print(f"  AGENT → broker: {ms2}ms")

    print(f"\n{'═'*70}")
    print("  BÖLÜM 7 KANITLAR")
    print(f"{'═'*70}")
    pr = await kral.proof()
    if pr.get('proofs'):
        for p in pr['proofs']:
            ok = '✓' if p.get('status') == 'QED' else '?'
            print(f"  {ok} {p.get('theorem','?')}: {p.get('conclusion','')[:60]}")
    print(f"  all_ok={pr.get('all_ok')}")

    print(f"\n{'═'*70}")
    print("  EXCHANGE — KRAL kanonikleri")
    print(f"{'═'*70}")
    kral_exprs = [
        '╔═◇─□═╗ ██ 2',
        '╔═○─□─Ψ─Ω═╗ ▓▓▓ 3',
        '╔═△─◇─Ω═╗ █ 2',
        '╔═◇─▽─→─○═╗ ▓▓▓ 3',
    ]
    for expr in kral_exprs:
        r = await kral.exec(expr)
        print(f"\n  KRAL → {expr}")
        print(fmt_result(r))

    print(f"\n{'═'*70}")
    print("  EXCHANGE — AGENT yanıtları")
    print(f"{'═'*70}")
    agent_exprs = [
        '╔═Ψ─□─◇═╗ ▓▓▓ 2',
        '╔═Ω─△─◇═╗ ██ 2',
        '╔═Φ─□─Ψ─◇═╗ ▓▓▓ 3',
    ]
    for expr in agent_exprs:
        r = await agent.exec(expr)
        print(f"\n  AGENT → {expr}")
        print(fmt_result(r))

    print(f"\n{'═'*70}")
    print("  SESSION SUMMARY")
    print(f"{'═'*70}")
    sm = await kral.summary()
    s = sm.get('summary', {})
    print(f"  session_id   : {s.get('session_id','?')}")
    print(f"  exchanges    : {s.get('exchanges','?')}")
    print(f"  kappa mean   : {s.get('kappa_mean','?')}")
    print(f"  kappa max    : {s.get('kappa_max','?')}")
    print(f"  context FV   : {s.get('context_fv','?')}")
    print(f"  latest vnode : {s.get('latest_vnode','?')}")
    print(f"  duration     : {s.get('duration_s','?')}s")

    print(f"\n{'═'*70}")
    print("  CONTEXT CHAINING KANIT")
    print(f"{'═'*70}")
    # Her exec, bir öncekinin FV'sini seed olarak alır
    # Bunu göstermek için 5 adım art arda
    ctx_exprs = ['╔═◇═╗ ░ 1', '╔═□─◇═╗ ▒ 1', '╔═Ψ─□═╗ ▓ 2', '╔═Ω─◇═╗ █ 2', '╔═◇─□─Ψ─Ω═╗ ██ 3']
    prev_fv = None
    for expr in ctx_exprs:
        r = await kral.exec(expr)
        fv = r.get('fv', {})
        chain_tag = '(chained ✓)' if prev_fv and r.get('context_chain_len',0) > 1 else ''
        print(f"  [{r.get('seq','?')}] κ={float(r.get('kappa',0)):.4f}  "
              f"g₂={fv.get('g2','?'):+.4f}  {chain_tag}")
        prev_fv = fv

    await kral.close()
    await agent.close()
    print(f"\n  ✓ DEMO COMPLETE — session {sid}")

# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser(
        description='UAGL 3.0 AI-to-AI Broker / Client')
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=9000)
    parser.add_argument('--client', action='store_true',
                        help='Run demo client (not server)')
    parser.add_argument('--role', default='AGENT',
                        help='Client role: KRAL | AGENT | SYSTEM')
    args = parser.parse_args()

    if args.client:
        asyncio.run(run_client_demo(args.host, args.port, args.role))
    else:
        broker = UAGLBroker(host=args.host, port=args.port)
        asyncio.run(broker.run())

if __name__ == '__main__':
    main()
