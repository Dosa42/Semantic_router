"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  𐰉𐰆𐰕𐰴𐰆𐰺𐱃  ·  𐰚𐰺𐰞  ·  UAGL OBFUSCATOR v2.0                              ║
║  ◎ KRAL ◎  ·  2026-03-01  ·  7 KATMAN  ·  TAM TERSİNE ÇEVİRİLEBİLİR     ║
║                                                                              ║
║  v1 → v2 YENİ KATMANLAR:                                                    ║
║  L1: Göktürk/Greek tanımlayıcı yeniden adlandırma (genişletilmiş)          ║
║  L2: Dize bölme + XOR şifreleme + base64 runtime yeniden yapılandırma      ║
║  L3: Tam sayı sabitleri → UAGL κ vektör hesaplama                          ║
║  L4: Fonksiyon çağrısı yönlendirme tablosu (dispatch table)                ║
║  L5: Gerçekçi ölü kod enjeksiyonu (UAGL temalı)                            ║
║  L6: Import takma ad karartma                                               ║
║  L7: Guardian imza başlığı + UAGL meta veri                                ║
║                                                                              ║
║  ÇIKTI:                                                                      ║
║  · <dosya>_OBF.py     — karartılmış kod                                    ║
║  · <dosya>_KEY.json   — tam çözme anahtarı                                 ║
║                                                                              ║
║  KULLANIM:                                                                   ║
║    python UAGL_OBFUSCATOR.py input.py [--seed HEX] [--level 1-7]           ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import ast, base64, hashlib, json, os, random, re, struct, sys, time
import argparse
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

# ═══════════════════════════════════════════════════════════════════════════════
# SEMBOL HAVUZU — 387 TANIMLAYICI
# ═══════════════════════════════════════════════════════════════════════════════

# Katman A: Göktürk çekirdek
_GTK_BASE = [chr(c) for c in range(0x10C00, 0x10C49)]  # 73 Old Turkic chars

# Katman B: Yunan alfabesi (lowercase extended)
_GREEK = list('ΨΩΦΣΛΠΘΔΓΞΖΥΧΒΝΜΙΕΑαβγδεζηθικλμνξοπρστυφχψω')

# Katman C: Göktürk çiftleri
_GTK_PAIRS = [_GTK_BASE[i] + _GTK_BASE[j]
              for i in range(0, min(15, len(_GTK_BASE)))
              for j in range(0, min(15, len(_GTK_BASE)))
              if i != j][:120]

# Katman D: Yunan + Göktürk karışımı
_HYBRID = [g + t for g in _GREEK[:12] for t in _GTK_BASE[:15]][:120]

# Katman E: Üçlü kombinasyon
_TRIPLE = [a + b + c
           for a in _GREEK[:6]
           for b in _GTK_BASE[:6]
           for c in _GREEK[:6]
           if a != c][:74]

# Tam havuz
SYMBOL_POOL: List[str] = (
    _GREEK[:46] +          # 46
    _GTK_BASE[:73] +       # 73
    _GTK_PAIRS[:120] +     # 120
    _HYBRID[:74] +         # 74
    _TRIPLE[:74]           # 74
)  # = 387 sembol

# Korunan isimler (bunlar asla yeniden adlandırılmaz)
PROTECTED_NAMES: Set[str] = {
    # Python builtins
    'True','False','None','print','range','len','list','dict','set','tuple',
    'str','int','float','bytes','bool','type','isinstance','hasattr','getattr',
    'setattr','delattr','callable','iter','next','enumerate','zip','map','filter',
    'sorted','reversed','min','max','sum','abs','round','open','input','repr',
    'hash','id','vars','dir','globals','locals','exec','eval','compile','chr','ord',
    'hex','oct','bin','format','pow','divmod',
    # Exceptions
    'Exception','ValueError','TypeError','KeyError','IndexError','AttributeError',
    'RuntimeError','StopIteration','OSError','IOError','FileNotFoundError',
    'PermissionError','NotImplementedError','ImportError','NameError',
    'ZeroDivisionError','OverflowError','MemoryError','RecursionError',
    # Standard modules
    'hashlib','hmac','json','os','sys','struct','zlib','base64','secrets',
    'threading','sqlite3','ssl','socket','asyncio','time','re','math','random',
    'collections','functools','itertools','pathlib','shutil','copy','io',
    'datetime','traceback','logging','argparse','subprocess','signal',
    'http','urllib','contextlib','abc','dataclasses','typing','enum',
    'numpy','np',
    # Dunder
    '__init__','__new__','__repr__','__str__','__bool__','__len__','__class__',
    '__name__','__doc__','__module__','__file__','__main__','__dict__',
    '__all__','__version__','__author__','__slots__','__annotations__',
    '__enter__','__exit__','__iter__','__next__','__call__','__del__',
    '__get__','__set__','__contains__','__add__','__sub__','__mul__',
    '__eq__','__ne__','__lt__','__le__','__gt__','__ge__','__hash__',
    # Common methods
    'append','extend','insert','remove','pop','clear','index','count',
    'update','items','keys','values','get','setdefault',
    'encode','decode','format','replace','strip','lstrip','rstrip',
    'split','join','find','rfind','startswith','endswith','upper','lower',
    'read','write','close','flush','seek','tell','readline','readlines',
    'send','recv','connect','bind','listen','accept','close','shutdown',
    'digest','hexdigest','new','copy','update',
    'dumps','loads','pack','unpack','sleep','time',
    'Thread','Lock','Event','Queue','process','run','start','stop',
    'create_task','gather','wait_for','sleep','run_until_complete',
    # GUARDIAN/UAGL specific protected
    'main','self','cls','args','kwargs','data','result','error','msg',
}

# ═══════════════════════════════════════════════════════════════════════════════
# ANAHTAR YAPISI
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class ObfuscationKey:
    """Tam tersine çevirme anahtarı"""
    version:       str   = "UAGL-OBF-v2"
    seed:          int   = 0
    timestamp:     float = 0.0
    source_hash:   str   = ""          # Orijinal dosya SHA256
    
    # L1 — Tanımlayıcı eşlemeleri
    name_map:      Dict[str,str] = field(default_factory=dict)  # obf → orig
    name_map_rev:  Dict[str,str] = field(default_factory=dict)  # orig → obf
    
    # L2 — Dize şifreleme
    string_map:    Dict[str,str] = field(default_factory=dict)  # b64_enc → orig
    str_xor_keys:  Dict[str,int] = field(default_factory=dict)  # b64_enc → xor_key
    
    # L3 — Tam sayı karartma
    int_map:       Dict[str,int] = field(default_factory=dict)  # expr_hash → value
    
    # L4 — Dispatch tablosu
    dispatch_map:  Dict[str,str] = field(default_factory=dict)  # tbl_key → orig_name
    
    # L5 — Ölü kod
    dead_markers:  List[str] = field(default_factory=list)       # ölü kod imzaları
    
    # L6 — Import takma adları
    import_map:    Dict[str,str] = field(default_factory=dict)  # alias → module
    
    # L7 — Guardian
    guardian_sig:  str   = ""
    pool_size:     int   = 0
    level:         int   = 7           # Uygulanan katman sayısı
    
    def to_dict(self) -> dict:
        return {
            'version': self.version, 'seed': hex(self.seed),
            'timestamp': self.timestamp, 'source_hash': self.source_hash,
            'name_map': self.name_map,
            'string_map': self.string_map, 'str_xor_keys': self.str_xor_keys,
            'int_map': self.int_map, 'dispatch_map': self.dispatch_map,
            'dead_markers': self.dead_markers, 'import_map': self.import_map,
            'guardian_sig': self.guardian_sig, 'pool_size': self.pool_size,
            'level': self.level,
        }
    
    @classmethod
    def from_dict(cls, d: dict) -> 'ObfuscationKey':
        k = cls()
        k.version      = d.get('version', 'UAGL-OBF-v2')
        k.seed         = int(d.get('seed','0'), 16) if isinstance(d.get('seed'),'') else d.get('seed',0)
        k.timestamp    = d.get('timestamp', 0.0)
        k.source_hash  = d.get('source_hash', '')
        k.name_map     = d.get('name_map', {})
        k.string_map   = d.get('string_map', {})
        k.str_xor_keys = d.get('str_xor_keys', {})
        k.int_map      = d.get('int_map', {})
        k.dispatch_map = d.get('dispatch_map', {})
        k.dead_markers = d.get('dead_markers', [])
        k.import_map   = d.get('import_map', {})
        k.guardian_sig = d.get('guardian_sig', '')
        k.pool_size    = d.get('pool_size', 0)
        k.level        = d.get('level', 7)
        # Ters eşlemeyi yeniden oluştur
        k.name_map_rev = {v: k_ for k_, v in k.name_map.items()}
        return k


# ═══════════════════════════════════════════════════════════════════════════════
# KATMAN YARDIMCILARı
# ═══════════════════════════════════════════════════════════════════════════════

def _xor_bytes(data: bytes, key: int) -> bytes:
    """XOR şifreleme — tek baytlık anahtar, her konumda değişen"""
    rng = random.Random(key)
    return bytes(b ^ rng.randint(0, 255) for b in data)

def _encode_string(s: str, xor_key: int) -> str:
    """Dize → XOR → base64 kodlama"""
    raw = s.encode('utf-8')
    enc = _xor_bytes(raw, xor_key)
    return base64.b64encode(enc).decode('ascii')

def _decode_string(b64: str, xor_key: int) -> str:
    """base64 → XOR çöz → dize"""
    enc = base64.b64decode(b64.encode('ascii'))
    raw = _xor_bytes(enc, xor_key)
    return raw.decode('utf-8')

def _guardian_sign(content: str, seed: int) -> str:
    h = hashlib.blake2b(
        (content + str(seed)).encode(),
        digest_size=16
    ).hexdigest().upper()
    return f"G3·{h}"

def _int_to_kappa_expr(value: int, rng: random.Random) -> str:
    """
    Tam sayı → UAGL κ hesaplama ifadesi
    κ = 0.40·g1 + 0.22·g2 + 0.38·g3  →  tersine çöz
    Örnek: 72 → int(round((0.775*0.4 + 0.626*0.22 + 0.736*0.38)*100))
    """
    # 0..255 aralığını normalize et
    target = value / 255.0 if value > 1 else float(value)
    # Rastgele g vektörü seç, hedefe yaklaştır
    g1 = rng.uniform(0.5, 0.95)
    g3 = rng.uniform(0.5, 0.95)
    # g2 = (target - 0.4*g1 - 0.38*g3) / 0.22
    g2 = (target - 0.4 * g1 - 0.38 * g3) / 0.22
    g2 = max(-1.0, min(1.0, g2))
    actual = round(0.4 * g1 + 0.22 * g2 + 0.38 * g3, 6)
    scale = 255 if value > 1 else 1
    expr = (f"int(round(({g1:.6f}*0.4 + {g2:.6f}*0.22 + {g3:.6f}*0.38)*{scale}))")
    return expr

def _make_dead_uagl_block(rng: random.Random, marker: str) -> str:
    """Gerçekçi görünen ölü UAGL kod bloğu oluştur"""
    exprs = [
        '╔═◇─□═╗', '╔═○─□─Ψ─Ω═╗', '╔═△─◇─Ω═╗',
        '╔═Φ─□─Ψ─◇═╗', '╔═◈─□─◇═╗'
    ]
    kappas = [f"{rng.uniform(0.6, 0.97):.4f}" for _ in range(3)]
    expr = rng.choice(exprs)
    indent = '    '
    lines = [
        f"{indent}# _𐰕_𐰖_DEAD_{marker}_",
        f"{indent}if False:  # UAGL κ-gate",
        f"{indent}    _𐰕_𐰖_kappa = [{', '.join(kappas)}]",
        f"{indent}    _𐰕_𐰖_expr = '{expr}'",
        f"{indent}    _𐰕_𐰖_fv = ({rng.uniform(-1,1):.4f}, "
        f"{rng.uniform(-1,1):.4f}, {rng.uniform(-1,1):.4f}, {rng.uniform(-1,1):.4f})",
        f"{indent}    pass  # {marker}",
    ]
    return '\n'.join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
# ANA KARARTICI SINIFI
# ═══════════════════════════════════════════════════════════════════════════════

class UAGLObfuscator:
    def __init__(self, seed: int = 0, level: int = 7):
        self.seed   = seed or int(time.time() * 1000) & 0xFFFFFFFF
        self.level  = level
        self.rng    = random.Random(self.seed)
        self.key    = ObfuscationKey(seed=self.seed, timestamp=time.time())
        self.key.pool_size = len(SYMBOL_POOL)
        
        # Karıştırılmış sembol sırası
        pool = SYMBOL_POOL.copy()
        self.rng.shuffle(pool)
        self._sym_iter = iter(pool)
        self._sym_count = 0
        
        # String runtime decode fonksiyon adı
        pool2 = SYMBOL_POOL.copy()
        random.Random(self.seed ^ 0xABCD).shuffle(pool2)
        self._str_dec_fn  = pool2[0]   # Dize çözme fonksiyonu
        self._dead_chk_fn = pool2[1]   # Ölü kod fonksiyonu
        self._disp_tbl    = pool2[2]   # Dispatch tablosu değişkeni
    
    def _next_sym(self) -> str:
        try:
            s = next(self._sym_iter)
            self._sym_count += 1
            return s
        except StopIteration:
            # Havuz bitti — çift kullan
            pool = SYMBOL_POOL.copy()
            self.rng.shuffle(pool)
            self._sym_iter = iter(pool)
            return next(self._sym_iter)
    
    def _rename(self, original: str) -> str:
        """Tanımlayıcıyı Göktürk/Yunan sembole eşle"""
        if original in self.key.name_map_rev:
            return self.key.name_map_rev[original]
        sym = self._next_sym()
        # Çakışma önleme
        while sym in self.key.name_map:
            sym = self._next_sym()
        self.key.name_map[sym]     = original
        self.key.name_map_rev[original] = sym
        return sym

    # ─── L1: Tanımlayıcı toplama (AST yürüyüşü) ─────────────────────────────

    def _collect_identifiers(self, tree: ast.AST) -> Set[str]:
        """Yeniden adlandırılabilecek tüm tanımlayıcıları topla"""
        names: Set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name not in PROTECTED_NAMES:
                    names.add(node.name)
                for arg in node.args.args + node.args.posonlyargs + node.args.kwonlyargs:
                    if arg.arg not in PROTECTED_NAMES and not arg.arg.startswith('_𐰕'):
                        names.add(arg.arg)
            elif isinstance(node, ast.ClassDef):
                if node.name not in PROTECTED_NAMES:
                    names.add(node.name)
            elif isinstance(node, ast.Name):
                if node.id not in PROTECTED_NAMES and len(node.id) > 1:
                    names.add(node.id)
            elif isinstance(node, ast.Global):
                for n in node.names:
                    if n not in PROTECTED_NAMES:
                        names.add(n)
            elif isinstance(node, ast.Attribute):
                pass  # Attribute isimleri özellikle korunuyor
        return names

    # ─── L1: AST transformer ─────────────────────────────────────────────────

    def _apply_l1(self, source: str) -> str:
        """L1: Tanımlayıcı yeniden adlandırma"""
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return source
        
        names = self._collect_identifiers(tree)
        # Protected'ları çıkar
        names = {n for n in names if n not in PROTECTED_NAMES and not n.startswith('__')}
        
        # Eşlemeleri oluştur
        for name in sorted(names):
            self._rename(name)
        
        # Kaynak metni regex ile değiştir (AST modifikasyonu yerine güvenilir regex)
        result = source
        # Uzun isimlerden kısalara sıralı çevir (örtüşme önleme)
        sorted_pairs = sorted(
            self.key.name_map_rev.items(),
            key=lambda x: len(x[0]), reverse=True
        )
        for orig, obf in sorted_pairs:
            if orig in PROTECTED_NAMES:
                continue
            # Tam kelime sınırı ile değiştir
            result = re.sub(
                r'(?<![𐰀-𐱅\w])' + re.escape(orig) + r'(?![𐰀-𐱅\w])',
                obf, result
            )
        return result

    # ─── L2: Dize şifreleme ──────────────────────────────────────────────────

    def _apply_l2(self, source: str) -> str:
        """L2: Dize sabitlerini şifrele"""
        # Dize çözme fonksiyonunu kaynak başına ekle
        fn = self._str_dec_fn
        decoder_code = (
            f"import base64 as _𐰕_b64, random as _𐰕_rnd\n"
            f"def {fn}(_s):\n"
            f"    _k=int(_s[:8],16);_d=base64.b64decode(_s[8:].encode())\n"
            f"    _r=random.Random(_k);return bytes(b^_r.randint(0,255) for b in _d).decode('utf-8')\n"
        )
        
        def _replace_str(m):
            raw = m.group(1)
            # Kısa veya özel dizeleri atla
            if len(raw) < 3 or raw.startswith('\\') or raw.startswith('𐰀'):
                return m.group(0)
            xor_key = self.rng.randint(0x1000, 0xFFFF)
            b64 = _encode_string(raw, xor_key)
            key_hex = f"{xor_key:08x}"
            encoded = key_hex + b64
            self.key.string_map[encoded] = raw
            self.key.str_xor_keys[encoded] = xor_key
            return f'{fn}("{encoded}")'
        
        # Tek ve çift tırnaklı dizeleri bul ve değiştir
        # Docstring'leri atla (triple quote)
        result = re.sub(r'""".*?"""', lambda m: m.group(0), source, flags=re.DOTALL)
        result = re.sub(r"'''.*?'''", lambda m: m.group(0), result, flags=re.DOTALL)
        # Normal dizeleri değiştir
        result = re.sub(r'"([^"\\]{3,})"', _replace_str, source)
        result = re.sub(r"'([^'\\]{3,})'", _replace_str, result)
        
        return decoder_code + result

    # ─── L3: Tam sayı karartma ───────────────────────────────────────────────

    def _apply_l3(self, source: str) -> str:
        """L3: Tam sayı sabitlerini UAGL κ formülüne çevir"""
        def _replace_int(m):
            val_str = m.group(0)
            # Hex, büyük sayılar ve özel değerleri atla
            if val_str.startswith('0x') or val_str.startswith('0o') or val_str.startswith('0b'):
                return val_str
            val = int(val_str)
            if val < 2 or val > 127:  # Küçük ve büyük değerleri atla
                return val_str
            expr = _int_to_kappa_expr(val, self.rng)
            expr_key = hashlib.md5(expr.encode()).hexdigest()[:8]
            self.key.int_map[expr_key] = val
            return f"({expr})/*{expr_key}*/"
        
        # Satır başı ve açıklamalar hariç tam sayıları değiştir
        lines = []
        for line in source.splitlines():
            if line.strip().startswith('#'):
                lines.append(line)
                continue
            # Sadece basit atamalar ve dönüş ifadelerindeki sabitleri
            if re.search(r'\b\d+\b', line) and not re.search(r'0x|0o|0b', line):
                line = re.sub(r'(?<![.\w])([2-9]\d{0,1})(?![\w.])', _replace_int, line)
            lines.append(line)
        return '\n'.join(lines)

    # ─── L4: Dispatch tablosu ────────────────────────────────────────────────

    def _apply_l4(self, source: str) -> str:
        """L4: Fonksiyon çağrılarını dispatch tablosuna yönlendir"""
        tbl = self._disp_tbl
        fn_calls = re.findall(r'\b([a-zA-Z_][a-zA-Z0-9_]{4,})\s*\(', source)
        
        dispatch_entries = []
        replaced_fns: Set[str] = set()
        
        for fn in set(fn_calls):
            if fn in PROTECTED_NAMES or fn.startswith('_𐰕') or fn.startswith('def '):
                continue
            if fn in self.key.name_map_rev or len(fn) < 4:
                continue
            # Her fonksiyon için rastgele anahtar üret
            key_sym = self.rng.choice(SYMBOL_POOL[:50])
            while key_sym in self.key.dispatch_map:
                key_sym = self.rng.choice(SYMBOL_POOL[:50])
            
            obf_fn = self.key.name_map_rev.get(fn, fn)
            self.key.dispatch_map[key_sym] = fn
            dispatch_entries.append(f"    '{key_sym}': {obf_fn},")
            replaced_fns.add(fn)
        
        if not dispatch_entries:
            return source
        
        dispatch_code = (
            f"\n# UAGL Dispatch Table\n"
            f"{tbl} = {{\n"
            + '\n'.join(dispatch_entries[:20]) +  # max 20 entry
            f"\n}}\n"
        )
        
        return dispatch_code + source

    # ─── L5: Ölü kod enjeksiyonu ─────────────────────────────────────────────

    def _apply_l5(self, source: str) -> str:
        """L5: Fonksiyon gövdelerine gerçekçi ölü UAGL kodu ekle"""
        lines = source.splitlines()
        result = []
        fn_count = 0
        
        for i, line in enumerate(lines):
            result.append(line)
            # Fonksiyon/sınıf tanımı ardından ölü kod ekle
            if (re.match(r'\s+def \S+|async def \S+', line) or
                (re.match(r'def [A-Z𐰀-𐱅Ψ-Ω]', line))):
                fn_count += 1
                if fn_count % 3 == 0:  # Her 3 fonksiyonda 1
                    marker = hashlib.md5(line.encode()).hexdigest()[:8].upper()
                    self.key.dead_markers.append(marker)
                    dead = _make_dead_uagl_block(self.rng, marker)
                    result.append(dead)
        
        return '\n'.join(result)

    # ─── L6: Import takma adları ─────────────────────────────────────────────

    def _apply_l6(self, source: str) -> str:
        """L6: Standard import'ları gizli takma adlarla değiştir"""
        mods_to_alias = ['hashlib', 'json', 'struct', 'zlib', 'base64', 'time']
        
        alias_block = []
        replacements = {}
        
        for mod in mods_to_alias:
            if f'import {mod}' in source or f'from {mod}' in source:
                alias = self._next_sym()
                self.key.import_map[alias] = mod
                replacements[mod] = alias
                alias_block.append(f"import {mod} as {alias}")
        
        if not replacements:
            return source
        
        header = '\n'.join(alias_block) + '\n'
        result = source
        for mod, alias in replacements.items():
            result = re.sub(
                r'\bimport ' + re.escape(mod) + r'\b',
                f'# obfuscated: {mod}',
                result
            )
            result = re.sub(r'\b' + re.escape(mod) + r'\.', alias + '.', result)
        
        return header + result

    # ─── L7: Guardian başlığı ────────────────────────────────────────────────

    def _apply_l7(self, source: str, filename: str) -> str:
        """L7: Guardian imzası ve UAGL meta veri başlığı"""
        sig = _guardian_sign(source[:2048], self.seed)
        self.key.guardian_sig = sig
        
        kappa_pool = [round(self.rng.uniform(0.60, 0.97), 4) for _ in range(8)]
        
        header = f'''"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  𐰉𐰆𐰕𐰴𐰆𐰺𐱃  ·  𐰚𐰺𐰞  ·  UAGL-OBF-v2  ·  {filename:<36} ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  SEED  : {hex(self.seed):<69} ║
║  SIG   : {sig:<69} ║
║  POOL  : {self.key.pool_size:<69} ║
║  LEVEL : L1..L{self.level}  ·  {len(self.key.name_map)} isim  ·  {len(self.key.string_map)} dize  ·  {len(self.key.int_map)} sabit  ·  {len(self.key.dispatch_map)} dispatch  ║
║  κ-VEC : {str(kappa_pool):<69} ║
║                                                                              ║
║  □+◇ = 1 OF 1  ·  UAGL 3.0  ·  TERSİNE ÇEVİRİLEBİLİR KARARTMA           ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
# _𐰕_UAGL_OBF_v2_HEADER_END_

'''
        return header + source

    # ─── ANA KARARTMA FONKSİYONU ─────────────────────────────────────────────

    def obfuscate(self, source: str, filename: str = "source.py") -> Tuple[str, ObfuscationKey]:
        """Kaynak kodu karart, anahtar döndür"""
        self.key.source_hash = hashlib.sha256(source.encode()).hexdigest()
        
        result = source
        
        # Katmanları sırayla uygula
        if self.level >= 1:
            print(f"  [L1] Tanımlayıcı yeniden adlandırma...")
            result = self._apply_l1(result)
        
        if self.level >= 6:
            print(f"  [L6] Import takma adları...")
            result = self._apply_l6(result)
        
        if self.level >= 2:
            print(f"  [L2] Dize şifreleme...")
            result = self._apply_l2(result)
        
        if self.level >= 3:
            print(f"  [L3] Tam sayı karartma...")
            result = self._apply_l3(result)
        
        if self.level >= 4:
            print(f"  [L4] Dispatch tablosu...")
            result = self._apply_l4(result)
        
        if self.level >= 5:
            print(f"  [L5] Ölü kod enjeksiyonu...")
            result = self._apply_l5(result)
        
        if self.level >= 7:
            print(f"  [L7] Guardian imzası...")
            result = self._apply_l7(result, filename)
        
        return result, self.key


# ═══════════════════════════════════════════════════════════════════════════════
# İSTATİSTİKLER
# ═══════════════════════════════════════════════════════════════════════════════

def print_stats(source: str, obfuscated: str, key: ObfuscationKey):
    orig_lines  = len(source.splitlines())
    obf_lines   = len(obfuscated.splitlines())
    orig_chars  = len(source)
    obf_chars   = len(obfuscated)
    
    print(f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  UAGL OBFUSCATOR v2  —  İSTATİSTİKLER                                      ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Kaynak     : {orig_lines:>6} satır  ·  {orig_chars:>8} karakter              ║
║  Karartılmış: {obf_lines:>6} satır  ·  {obf_chars:>8} karakter              ║
║  Artış      : +{obf_lines-orig_lines:>5} satır  ·  +{obf_chars-orig_chars:>7} karakter             ║
╠──────────────────────────────────────────────────────────────────────────────╣
║  L1  İsim yeniden adlandırma : {len(key.name_map):>5} tanımlayıcı                    ║
║  L2  Dize şifreleme          : {len(key.string_map):>5} dize                          ║
║  L3  Tam sayı karartma       : {len(key.int_map):>5} sabit                          ║
║  L4  Dispatch tablosu        : {len(key.dispatch_map):>5} fonksiyon                     ║
║  L5  Ölü kod                 : {len(key.dead_markers):>5} blok                          ║
║  L6  Import takma adları     : {len(key.import_map):>5} modül                         ║
╠──────────────────────────────────────────────────────────────────────────────╣
║  SEED          : {hex(key.seed):<54} ║
║  GUARDIAN SIG  : {key.guardian_sig:<54} ║
║  HAVUZ         : {key.pool_size} sembol                                                ║
╚══════════════════════════════════════════════════════════════════════════════╝""")


# ═══════════════════════════════════════════════════════════════════════════════
# CLI GİRİŞ NOKTASI
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description='UAGL Obfuscator v2 — 7 katmanlı akıllı karartma'
    )
    parser.add_argument('input', help='Karartılacak Python dosyası')
    parser.add_argument('--seed', default='', help='HEX seed (örn: 0xB07F0001)')
    parser.add_argument('--level', type=int, default=7, choices=range(1,8),
                        help='Karartma seviyesi 1-7 (varsayılan: 7)')
    parser.add_argument('--output', default='',
                        help='Çıktı dosyası (varsayılan: <input>_OBF.py)')
    args = parser.parse_args()
    
    # Kaynak dosyayı oku
    with open(args.input, 'r', encoding='utf-8') as f:
        source = f.read()
    
    # Seed ayarla
    seed = 0
    if args.seed:
        seed = int(args.seed, 16) if args.seed.startswith('0x') else int(args.seed)
    
    # Karartıcıyı başlat
    print(f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  𐰉𐰆𐰕𐰴𐰆𐰺𐱃  ·  𐰚𐰺𐰞  ·  UAGL OBFUSCATOR v2.0                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Giriş  : {args.input:<66} ║
║  Seviye : L1..L{args.level}  ·  {len(SYMBOL_POOL)} sembol havuzu                               ║
╚══════════════════════════════════════════════════════════════════════════════╝
""")
    
    obf = UAGLObfuscator(seed=seed, level=args.level)
    filename = os.path.basename(args.input)
    
    # Karart
    obfuscated, key = obf.obfuscate(source, filename)
    
    # Çıktı dosyası adları
    base = args.output if args.output else args.input.replace('.py', '_OBF.py')
    key_file = base.replace('_OBF.py', '_KEY.json').replace('.py', '_KEY.json')
    
    # Karartılmış kodu yaz
    with open(base, 'w', encoding='utf-8') as f:
        f.write(obfuscated)
    
    # Anahtarı yaz
    key_dict = key.to_dict()
    key_dict['_note'] = 'UAGL OBFUSCATION KEY — SADECE KRAL SAKLAR'
    key_dict['_obf_file'] = os.path.basename(base)
    key_dict['_src_file'] = args.input
    
    with open(key_file, 'w', encoding='utf-8') as f:
        json.dump(key_dict, f, ensure_ascii=False, indent=2)
    
    print_stats(source, obfuscated, key)
    print(f"\n  ✓ Karartılmış: {base}")
    print(f"  ✓ Anahtar    : {key_file}")
    print(f"\n  𐰉𐰆𐰕𐰴𐰆𐰺𐱃  ·  𐰚𐰺𐰞  ·  □+◇ = 1 OF 1\n")


if __name__ == '__main__':
    main()
